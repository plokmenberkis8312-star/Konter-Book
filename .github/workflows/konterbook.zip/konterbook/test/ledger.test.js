import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createBook, openAccount, recordSale, transfer, reverseEntry,
  postEntry, profitLoss, balance, isBalanced, snapshot, restore,
} from '../www/src/core/ledger.js';
import { formatRupiah, parseRupiah } from '../www/src/core/money.js';

const D = '2026-11-19';
const fresh = () => {
  const b = createBook();
  openAccount(b, { date: D, account: '1201', amount: 100000 });
  openAccount(b, { date: D, account: '1101', amount: 50000 });
  return b;
};
const sale = { date: D, ref: 'T1', product: 'Pulsa 10rb', cost: 10000, price: 12000, fee: 500 };

test('untung bersih: 12.000 - 10.000 - 500 = 1.500', () => {
  const b = fresh();
  recordSale(b, sale);
  assert.deepEqual(profitLoss(b, D, D), { revenue: 12000, cogs: 10000, expense: 500, gross: 2000, net: 1500 });
  assert.equal(balance(b, '1201'), 89500);
  assert.equal(balance(b, '1101'), 62000);
  assert.ok(isBalanced(b));
});

test('transfer internal bukan omzet maupun untung', () => {
  const b = fresh();
  transfer(b, { date: D, from: '1101', to: '1102', amount: 30000 });
  assert.equal(profitLoss(b, D, D).revenue, 0);
  assert.equal(balance(b, '1101'), 20000);
  assert.equal(balance(b, '1102'), 30000);
});

test('transaksi gagal/refund: pembalikan menihilkan penjualan, data tidak dihapus', () => {
  const b = fresh();
  const e = recordSale(b, sale);
  reverseEntry(b, e.id, { date: D, reason: 'gagal dari server' });
  assert.equal(profitLoss(b, D, D).net, 0);
  assert.equal(balance(b, '1201'), 100000);
  assert.equal(b.entries.length, 4);
  assert.throws(() => reverseEntry(b, e.id, { date: D, reason: 'lagi' }), /sudah dibalik/);
  recordSale(b, sale); // ref boleh dipakai ulang setelah dibalik
});

test('deteksi duplikat via ref', () => {
  const b = fresh();
  recordSale(b, sale);
  assert.throws(() => recordSale(b, sale), /duplikat/);
});

test('saldo negatif ditolak tanpa izin', () => {
  const b = fresh();
  const big = { ...sale, ref: 'T2', cost: 200000, price: 250000 };
  assert.throws(() => recordSale(b, big), /tidak cukup/);
  recordSale(b, { ...big, allowNegative: true });
  assert.equal(balance(b, '1201'), 100000 - 200500);
});

test('validasi: float, tidak seimbang, jual di bawah modal', () => {
  const b = fresh();
  assert.throws(() => recordSale(b, { ...sale, price: 12000.5 }), /bilangan bulat/);
  assert.throws(() => postEntry(b, { date: D, lines: [{ account: '1101', debit: 100 }, { account: '3101', credit: 90 }] }), /tidak seimbang/);
  assert.throws(() => recordSale(b, { ...sale, ref: 'T9', price: 10000 }), /di bawah modal/);
});

test('rupiah: parse dan format', () => {
  assert.equal(parseRupiah('Rp12.000'), 12000);
  assert.equal(formatRupiah(1500), 'Rp1.500');
  assert.throws(() => parseRupiah('12.5'), /Desimal/);
});

test('backup dan restore mempertahankan saldo', () => {
  const b = fresh();
  recordSale(b, sale);
  const r = restore(snapshot(b));
  assert.equal(balance(r, '1201'), 89500);
  assert.equal(profitLoss(r, D, D).net, 1500);
});

import { addTransaction, setStatus } from '../www/src/core/ledger.js';

test('status: pending/gagal tidak masuk jurnal, berhasil masuk, refund membalik', () => {
  const b = fresh();
  const t = addTransaction(b, { date: D, product: 'Pulsa 10rb', cost: 10000, price: 12000, fee: 500 });
  assert.equal(profitLoss(b, D, D).revenue, 0);
  setStatus(b, t.id, 'berhasil', D);
  assert.equal(profitLoss(b, D, D).net, 1500);
  setStatus(b, t.id, 'refund', D);
  assert.equal(profitLoss(b, D, D).net, 0);
  assert.throws(() => setStatus(b, t.id, 'berhasil', D), /tidak bisa/);
  const g = addTransaction(b, { date: D, product: 'X', cost: 5000, price: 6000 });
  setStatus(b, g.id, 'gagal', D);
  assert.equal(profitLoss(b, D, D).revenue, 0);
});

test('transaksi berhasil dengan saldo kurang ditolak dan tidak tersimpan', () => {
  const b = fresh();
  assert.throws(() => addTransaction(b, { date: D, product: 'Besar', cost: 200000, price: 250000, status: 'berhasil' }), /tidak cukup/);
  assert.equal(b.transactions.length, 0);
});

test('pengeluaran, transfer, pendapatan tanpa modal, dan pembatalan', () => {
  const b = fresh();
  const ex = addTransaction(b, { kind: 'expense', date: D, price: 20000, category: 'Listrik', method: '1101' });
  assert.equal(ex.status, 'berhasil');
  assert.equal(balance(b, '1101'), 30000);
  addTransaction(b, { kind: 'transfer', date: D, price: 10000, source: '1101', method: '1102' });
  assert.equal(balance(b, '1102'), 10000);
  addTransaction(b, { kind: 'income', date: D, price: 5000, status: 'berhasil', method: '1101' });
  assert.deepEqual(profitLoss(b, D, D), { revenue: 5000, cogs: 0, expense: 20000, gross: 5000, net: -15000 });
  setStatus(b, ex.id, 'dibatalkan', D);
  assert.equal(profitLoss(b, D, D).expense, 0);
  assert.equal(balance(b, '1101'), 45000);
  assert.throws(() => addTransaction(b, { date: 'x', price: 1000 }), /Tanggal/);
  assert.throws(() => addTransaction(b, { kind: 'transfer', date: D, price: 1000, source: '1101', method: '1101' }), /berbeda/);
  assert.equal(b.transactions.length, 3);
});

import { addCategory, removeCategory } from '../www/src/core/ledger.js';

test('kategori kustom: tambah, duplikat, hapus, ikut backup, backup lama tetap terbaca', () => {
  const b = createBook();
  assert.equal(addCategory(b, 'income', '  Kartu   Perdana '), 'Kartu Perdana');
  assert.throws(() => addCategory(b, 'income', 'kartu perdana'), /sudah ada/);
  assert.throws(() => addCategory(b, 'income', ''), /wajib/);
  assert.throws(() => addCategory(b, 'transfer', 'X'), /tidak valid/);
  const r = restore(snapshot(b));
  assert.ok(r.categories.income.includes('Kartu Perdana'));
  removeCategory(r, 'income', 'Kartu Perdana');
  assert.ok(!r.categories.income.includes('Kartu Perdana'));
  const old = JSON.parse(snapshot(createBook())); delete old.categories;
  assert.ok(restore(JSON.stringify(old)).categories.expense.length > 0);
  const c = createBook(); c.categories.expense = ['A'];
  assert.throws(() => removeCategory(c, 'expense', 'A'), /Minimal/);
});

import { settleTransaction, addAccount, removeAccount } from '../www/src/core/ledger.js';
import { demoBook } from '../www/src/core/demo.js';

test('belum bayar jadi piutang, lunas memindahkan ke akun, refund membalik keduanya', () => {
  const b = fresh();
  const t = addTransaction(b, { date: D, product: 'Pulsa', cost: 10000, price: 12000, fee: 500, status: 'berhasil', paid: false, method: '1101' });
  assert.equal(balance(b, '1301'), 12000);
  assert.equal(balance(b, '1101'), 50000);
  assert.equal(profitLoss(b, D, D).net, 1500);
  settleTransaction(b, t.id, D);
  assert.equal(balance(b, '1301'), 0);
  assert.equal(balance(b, '1101'), 62000);
  assert.throws(() => settleTransaction(b, t.id, D), /tidak menunggu/);
  setStatus(b, t.id, 'refund', D);
  assert.equal(balance(b, '1301'), 0);
  assert.equal(balance(b, '1101'), 50000);
  assert.equal(balance(b, '1201'), 100000);
  assert.equal(profitLoss(b, D, D).net, 0);
  assert.ok(isBalanced(b));
});

test('refund gagal tidak meninggalkan jurnal setengah jadi', () => {
  const b = fresh();
  const t = addTransaction(b, { date: D, product: 'Pulsa', cost: 10000, price: 12000, status: 'berhasil', paid: false });
  settleTransaction(b, t.id, D);
  addTransaction(b, { kind: 'expense', date: D, price: 55000, method: '1101' });
  const n = b.entries.length;
  assert.throws(() => setStatus(b, t.id, 'refund', D), /tidak cukup/);
  assert.equal(b.entries.length, n);
  assert.equal(t.status, 'berhasil');
  assert.ok(isBalanced(b));
});

test('akun kustom: tambah, dipakai, tidak bisa dihapus bila punya riwayat', () => {
  const b = fresh();
  const code = addAccount(b, ' DANA  ');
  assert.equal(b.accounts[code].name, 'DANA');
  assert.throws(() => addAccount(b, 'dana'), /sudah ada/);
  assert.throws(() => addAccount(b, 'tunai'), /sudah ada/);
  openAccount(b, { date: D, account: code, amount: 20000 });
  assert.equal(balance(b, code), 20000);
  assert.throws(() => removeAccount(b, code), /riwayat/);
  assert.throws(() => removeAccount(b, '1101'), /bawaan/);
  const c = addAccount(b, 'Bank BRI');
  removeAccount(b, c);
  assert.equal(b.accounts[c], undefined);
});

test('data contoh valid, seimbang, ada piutang dan untung', () => {
  const b = demoBook();
  assert.ok(isBalanced(b));
  assert.ok(balance(b, '1301') > 0);
  assert.ok(profitLoss(b, '0000-01-01', '9999-12-31').net > 0);
  assert.ok(b.transactions.length >= 10);
});

import { editTransaction } from '../www/src/core/ledger.js';

test('edit transaksi: koreksi nominal/tanggal/status bayar/jenis, jurnal lama dibalik', () => {
  const b = fresh();
  const t = addTransaction(b, { date: D, time: '10:15', product: 'Pulsa', cost: 10000, price: 12000, fee: 500, status: 'berhasil', method: '1101' });
  assert.equal(t.time, '10:15');
  editTransaction(b, t.id, { price: 13000, date: '2026-11-18', time: '09:00' });
  assert.equal(t.date, '2026-11-18');
  assert.equal(profitLoss(b, D, D).net, 0);
  assert.equal(profitLoss(b, '2026-11-18', '2026-11-18').net, 2500);
  assert.equal(balance(b, '1101'), 63000);
  assert.equal(balance(b, '1201'), 89500);
  editTransaction(b, t.id, { paid: false });
  assert.equal(balance(b, '1301'), 13000);
  assert.equal(balance(b, '1101'), 50000);
  settleTransaction(b, t.id, D);
  assert.equal(balance(b, '1101'), 63000);
  editTransaction(b, t.id, { kind: 'expense', price: 3000, method: '1101' });
  assert.equal(profitLoss(b, '2026-11-18', '2026-11-18').revenue, 0);
  assert.equal(balance(b, '1201'), 100000);
  assert.equal(balance(b, '1101'), 47000);
  assert.ok(isBalanced(b));
});

test('edit: transaksi tertutup ditolak, edit yang gagal dibatalkan total', () => {
  const b = fresh();
  const g = addTransaction(b, { date: D, product: 'X', cost: 5000, price: 6000 });
  setStatus(b, g.id, 'gagal', D);
  assert.throws(() => editTransaction(b, g.id, { price: 7000 }), /ditutup/);
  const t = addTransaction(b, { date: D, product: 'Pulsa', cost: 10000, price: 12000, status: 'berhasil' });
  const n = b.entries.length;
  assert.throws(() => editTransaction(b, t.id, { cost: 500000, price: 600000 }), /tidak cukup/);
  assert.equal(b.entries.length, n);
  assert.equal(t.price, 12000);
  assert.equal(balance(b, '1201'), 90000);
  assert.throws(() => editTransaction(b, t.id, { time: '25:99' }), /Jam/);
});
