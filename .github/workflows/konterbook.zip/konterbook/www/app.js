import { demoBook } from './src/core/demo.js';
import { evalExpr, pressKey, fmtExpr } from './src/core/calc.js';
import { createBook, restore, snapshot, balance, addTransaction, setStatus, openAccount, profitLoss, CATEGORY_LIST, EXPENSE_CATS, addCategory, removeCategory, addAccount, removeAccount, settleTransaction, editTransaction, ACCOUNT_SHORT } from './src/core/ledger.js';
import { parseRupiah, formatRupiah as rp } from './src/core/money.js';
import { loadSnapshot, saveSnapshot } from './src/db/idb.js';

const $ = (s) => document.querySelector(s);
const esc = (s) => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const ymd = (d) => d.toLocaleDateString('sv-SE');
const today = () => ymd(new Date());
let book = null, view = 'home', period = 'day', draft = null;
let storage = true, demo = false, txTab = 'day', selDay = null, pieMode = 'count', fresh = '';
let openKeys = new Set([`m:${ymd(new Date()).slice(0, 7)}`]);
let mon = { y: new Date().getFullYear(), m: new Date().getMonth() };

function toast(m) { const t = $('#toast'); t.textContent = m; t.hidden = false; setTimeout(() => (t.hidden = true), 3500); }

function range() {
  const t = new Date(), end = today();
  if (period === 'all') return ['0000-01-01', '9999-12-31'];
  if (period === 'day') return [end, end];
  if (period === 'week') { const s = new Date(t); s.setDate(t.getDate() - 6); return [ymd(s), end]; }
  if (period === 'month') return [ymd(new Date(t.getFullYear(), t.getMonth(), 1)), end];
  return [ymd(new Date(t.getFullYear(), 0, 1)), end];
}

const I = {
  up: 'M4 16l5-5 4 4 7-8M15 7h5v5',
  down: 'M4 8l5 5 4-4 7 8M15 17h5v-5',
  box: 'M4 7l8-4 8 4v10l-8 4-8-4zM4 7l8 4 8-4M12 11v10',
  check: 'M5 12l5 5 9-10',
  wallet: 'M4 7h14a2 2 0 012 2v9a2 2 0 01-2 2H4zM4 7l12-3v3M16 13.5h.01',
  bank: 'M3 10l9-6 9 6M5 10v8M9 10v8M15 10v8M19 10v8M3 20h18',
  server: 'M4 5h16v5H4zM4 14h16v5H4zM8 7.5h.01M8 16.5h.01',
  phone: 'M8 3h8a1 1 0 011 1v16a1 1 0 01-1 1H8a1 1 0 01-1-1V4a1 1 0 011-1zM11 18h2',
  plus: 'M12 5v14M5 12h14',
};
const ico = (k) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="${I[k]}"/></svg>`;
const tile = (label, value, icon, extra = '') =>
  `<div class="tile"><span class="ic">${ico(icon)}</span><div><small>${label}</small><b>${value}</b>${extra}</div></div>`;
const LABEL = { day: 'Hari ini', week: '7 hari terakhir', month: 'Bulan ini', year: 'Tahun ini', all: 'Semua waktu' };

const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
const CHART_LABEL = { day: '7 hari terakhir', week: '7 hari terakhir', month: 'bulan ini', year: 'per bulan', all: '12 bulan terakhir' };

function buckets() {
  const t = new Date(), out = [];
  if (period === 'all') return allBuckets();
  if (period === 'year') {
    for (let m = 0; m < 12; m++) out.push({ l: MON[m], a: ymd(new Date(t.getFullYear(), m, 1)), b: ymd(new Date(t.getFullYear(), m + 1, 0)) });
  } else {
    const n = period === 'month' ? t.getDate() : 7;
    for (let i = n - 1; i >= 0; i--) { const d = new Date(t); d.setDate(t.getDate() - i); out.push({ l: String(d.getDate()), a: ymd(d), b: ymd(d) }); }
  }
  return out;
}

const short = (v) => v >= 1e6 ? `${+(v / 1e6).toFixed(1)}jt` : v >= 1e3 ? `${Math.round(v / 1e3)}rb` : String(v);
const nice = (v) => { const p = 10 ** Math.floor(Math.log10(v)); return [1, 2, 5, 10].map(x => x * p).find(x => x >= v); };

function chart() {
  const data = buckets().map(k => { const p = profitLoss(book, k.a, k.b); return { l: k.l, i: p.revenue, o: p.cogs + p.expense }; });
  const max = nice(Math.max(10000, ...data.map(d => Math.max(d.i, d.o))));
  const W = 320, L = 34, H = 130, gw = (W - L) / data.length, bw = Math.min(14, gw * 0.36), step = Math.ceil(data.length / 8);
  const y = (v) => H - (v / max) * (H - 6);
  const pre = period === 'year' || period === 'all' ? '' : 'Tgl ';
  const bar = (x, v, c, k) => v > 0
    ? `<rect class="${c}" style="animation-delay:${k * 30}ms" x="${x.toFixed(1)}" y="${y(v).toFixed(1)}" width="${bw.toFixed(1)}" height="${(H - y(v)).toFixed(1)}" rx="${Math.min(3, bw / 2).toFixed(1)}"/>` : '';
  const groups = data.map((d, k) => {
    const x = L + k * gw + gw / 2;
    return `<g class="grp" data-t="${pre}${d.l}: Pemasukan ${rp(d.i)} · Modal + biaya ${rp(d.o)}">
      <rect class="hit" x="${(x - gw / 2).toFixed(1)}" y="0" width="${gw.toFixed(1)}" height="${H + 20}"/>
      ${bar(x - bw - 0.5, d.i, 'b1', k)}${bar(x + 0.5, d.o, 'b2', k)}
      ${k % step === 0 ? `<text class="ax" x="${x.toFixed(1)}" y="${H + 14}" text-anchor="middle">${d.l}</text>` : ''}</g>`;
  }).join('');
  const tot = data.reduce((s, d) => ({ i: s.i + d.i, o: s.o + d.o }), { i: 0, o: 0 });
  return `<div class="tile span2 chart"><small>Pemasukan vs pengeluaran · ${CHART_LABEL[period]}</small>
    <svg viewBox="0 0 ${W} ${H + 20}" role="img" aria-label="Grafik pemasukan dan pengeluaran">
      <line class="gl" x1="${L}" x2="${W}" y1="${y(max)}" y2="${y(max)}"/><line class="gl" x1="${L}" x2="${W}" y1="${y(max / 2)}" y2="${y(max / 2)}"/><line class="gl" x1="${L}" x2="${W}" y1="${H}" y2="${H}"/>
      <text class="ax" x="0" y="${y(max) + 3}">${short(max)}</text><text class="ax" x="0" y="${y(max / 2) + 3}">${short(max / 2)}</text>${groups}</svg>
    <div class="readout">Ketuk batang untuk melihat detail</div>
    <div class="legend"><span><i class="b1"></i>Pemasukan ${rp(tot.i)}</span><span><i class="b2"></i>Modal + biaya ${rp(tot.o)}</span></div></div>`;
}

function saldoHero() {
  const custom = Object.keys(book.accounts).filter(c => c.startsWith('14'));
  const parts = [['Tunai', balance(book, '1101'), 'c1'], ['Bank', balance(book, '1102'), 'c2'],
    ['Deposit', balance(book, '1201') + balance(book, '1202'), 'c3'], ['E-wallet', balance(book, '1203'), 'c4'],
    ...(custom.length ? [['Lainnya', custom.reduce((s, c) => s + balance(book, c), 0), 'c5']] : [])];
  const total = parts.reduce((s, p) => s + p[1], 0);
  return `<div class="tile hero span2"><div><small>Total saldo</small><b>${rp(total)}</b></div>
    <div class="stack">${parts.map(([, v, c]) => `<i class="${c}" style="flex:${Math.max(0, v)}"></i>`).join('')}</div>
    <div class="legend">${parts.map(([l, v, c]) => `<span><i class="${c}"></i>${l}<em>${rp(v)}</em></span>`).join('')}</div></div>`;
}

function home() {
  const [a, b] = range(), p = profitLoss(book, a, b);
  const tx = book.transactions.filter(x => x.date >= a && x.date <= b);
  const n = (...s) => tx.filter(x => s.includes(x.status)).length;
  const seg = [['day', 'Hari'], ['week', 'Minggu'], ['month', 'Bulan'], ['year', 'Tahun'], ['all', 'Semua']]
    .map(([k, l]) => `<button data-period="${k}" class="${period === k ? 'on' : ''}">${l}</button>`).join('');
  return `${emptyHint()}<div class="bento">${saldoHero()}</div>
  <div class="seg">${seg}</div>
  <div class="bento">
    <div class="tile ink span2"><small>Untung bersih · ${LABEL[period]}</small><b>${rp(p.net)}</b><div class="sub">${n('berhasil')} transaksi berhasil</div></div>
    ${tile('Omzet', rp(p.revenue), 'up')}
    ${tile('Untung kotor', rp(p.gross), 'box')}
    ${tile('Pengeluaran', rp(p.expense), 'down')}
    ${tile('Transaksi', `${n('berhasil')} / ${n('gagal', 'dibatalkan')}`, 'check', '<small>berhasil / gagal</small>')}
    ${chart()}
    ${pie()}
  </div>
  <h3>Menu cepat</h3>
  <div class="bento">
    <button class="tile act" data-new="1"><span class="ic">${ico('plus')}</span><b>Transaksi baru</b></button>
    <button class="tile act" data-v="kas"><span class="ic">${ico('wallet')}</span><b>Kelola kas</b></button>
  </div>`;
}

const pick = (name, items, sel) => `<div class="pick"><input type="hidden" name="${name}" value="${esc(sel)}">${items.map(([v, l]) =>
  `<button type="button" data-pick="${esc(v)}" class="${v === sel ? 'on' : ''}">${esc(l)}</button>`).join('')}</div>`;
const accOpts = (codes) => codes.map(c => [c, book.accounts[c].name]);
const ACC_ICON = { 1101: 'wallet', 1102: 'bank', 1201: 'server', 1202: 'server', 1203: 'phone', 1301: 'box' };

const MON_FULL = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
const DAY = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];
// Nama akun: bawaan dari ACCOUNT_SHORT, akun kustom dari buku.
const SHORT = new Proxy(ACCOUNT_SHORT, { get: (o, k) => o[k] ?? book?.accounts?.[k]?.name });
const KIND = { income: 'Pendapatan', expense: 'Pengeluaran', transfer: 'Transfer' };
const LBL = { price: 'Total', cost: 'Modal', fee: 'Biaya' };
const KEYS = [['1', '1'], ['2', '2'], ['3', '3'], ['back', '⌫', 'k-alt'], ['4', '4'], ['5', '5'], ['6', '6'], ['calc', '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8M8 12h.01M12 12h.01M16 12h.01M8 16h.01M12 16h.01M16 16h.01"/></svg>', 'k-alt'],
  ['7', '7'], ['8', '8'], ['9', '9'], ['done', 'Selesai', 'k-done'], ['clear', 'C', 'k-alt'], ['0', '0'], ['000', '000']];
const aset = (codes) => codes.map(c => [c, SHORT[c]]);

let tok = 0;
const nowHM = () => new Date().toTimeString().slice(0, 5);
const inOut = (a, b) => { const p = profitLoss(book, a, b); return { i: p.revenue, o: p.cogs + p.expense, n: p.net }; };
const sumRow = (x) => `<div class="sum"><div><small>Pendapatan</small><b class="in">${rp(x.i)}</b></div><div><small>Pengeluaran</small><b class="out">${rp(x.o)}</b></div><div><small>Total</small><b>${rp(x.n)}</b></div></div>`;
const daysOf = (a, b) => [...new Set(book.transactions.filter(t => t.date >= a && t.date <= b).map(t => t.date))].sort().reverse();

function txItem(t) {
  const dead = ['gagal', 'dibatalkan', 'refund'].includes(t.status);
  const cls = { income: 'in', expense: 'out', transfer: 'tr' }[t.kind];
  const unpaid = t.kind === 'income' && t.status === 'berhasil' && t.paid === false;
  const sub = (t.time ? `${t.time} · ` : '') + (t.kind === 'transfer' ? `${SHORT[t.source]} → ${SHORT[t.method]}` : unpaid ? 'Piutang' : SHORT[t.method]) +
    (unpaid ? ' <em class="st belum">belum bayar</em>' : t.status === 'berhasil' ? '' : ` <em class="st ${t.status}">${t.status}</em>`);
  const gain = t.kind === 'income' && t.cost > 0 ? `<small>untung ${rp(t.price - t.cost - t.fee)}</small>` : '';
  return `<button class="item ${dead ? 'dead' : ''}" data-open="${t.id}"><span class="cat">${esc(t.category)}</span>
    <span class="mid"><b>${esc(t.product)}</b><small>${sub}</small></span><span class="amt ${cls}">${rp(t.price)}${gain}</span></button>`;
}

function dayBlock(d) {
  const dt = new Date(`${d}T00:00:00`), x = inOut(d, d);
  const rows = book.transactions.filter(t => t.date === d).sort((p, q) => (q.time ?? '').localeCompare(p.time ?? '') || q.id.localeCompare(p.id));
  return `<div class="day"><span class="dn">${dt.getDate()}</span><i class="wd">${DAY[dt.getDay()]}</i><small>${d.slice(5, 7)}.${d.slice(0, 4)}</small>
    <b class="in">${rp(x.i)}</b><b class="out">${rp(x.o)}</b></div>
    ${rows.length ? `<div class="items">${rows.map(txItem).join('')}</div>` : '<p class="empty">Tidak ada transaksi.</p>'}`;
}

const dayView = (key) => daysOf(`${key}-01`, `${key}-31`).map(d => dayBlock(d)).join('') || '<p class="empty">Belum ada transaksi bulan ini.</p>';

function calView(key) {
  const { y, m } = mon, first = new Date(y, m, 1).getDay(), n = new Date(y, m + 1, 0).getDate(), t0 = today();
  const sel = selDay ?? (key === t0.slice(0, 7) ? t0 : null);
  const cells = Array(first).fill('<span class="cc off"></span>');
  for (let d = 1; d <= n; d++) {
    const ds = `${key}-${String(d).padStart(2, '0')}`, x = inOut(ds, ds);
    cells.push(`<button class="cc ${ds === t0 ? 'now' : ''} ${ds === sel ? 'on' : ''}" data-day="${ds}"><b>${d}</b>${x.i > 0 ? `<em class="in">${short(x.i)}</em>` : ''}${x.o > 0 ? `<em class="out">${short(x.o)}</em>` : ''}</button>`);
  }
  return `<div class="cal"><div class="cw">${DAY.map(x => `<span>${x}</span>`).join('')}</div><div class="cg">${cells.join('')}</div></div>
    ${sel && sel.startsWith(key) ? dayBlock(sel) : '<p class="empty">Ketuk tanggal untuk melihat transaksinya.</p>'}`;
}

function weeksOf(y, m, endD, isFresh) {
  const pad = (n) => String(n).padStart(2, '0'), out = [];
  for (let d = 1; d <= endD;) {
    const e = Math.min(endD, d + (6 - new Date(y, m, d).getDay()));
    const from = `${y}-${pad(m + 1)}-${pad(d)}`, to = `${y}-${pad(m + 1)}-${pad(e)}`, x = inOut(from, to), wk = `w:${from}`, isOpen = openKeys.has(wk);
    out.push(`<div class="wgroup"><button class="wrow" data-tg="${wk}"><span>${pad(d)}.${pad(m + 1)} ~ ${pad(e)}.${pad(m + 1)}</span>
      <span class="mv"><b class="in">${rp(x.i)}</b><b class="out">${rp(x.o)}</b><small>${rp(x.n)}</small></span></button>
      ${isOpen ? `<div class="wbody ${fresh === wk ? 'fresh' : ''}">${daysOf(from, to).map(dd => dayBlock(dd)).join('') || '<p class="empty">Tidak ada transaksi.</p>'}</div>` : ''}</div>`);
    d = e + 1;
  }
  return `<div class="weeks ${isFresh ? 'fresh' : ''}">${out.reverse().join('')}</div>`;
}

function monthView() {
  const y = mon.y, now = new Date(), last = y === now.getFullYear() ? now.getMonth() : 11, rows = [];
  for (let m = last; m >= 0; m--) {
    const mm = String(m + 1).padStart(2, '0'), key = `${y}-${mm}`, endD = new Date(y, m + 1, 0).getDate();
    const x = inOut(`${key}-01`, `${key}-${endD}`), isOpen = openKeys.has(`m:${key}`);
    rows.push(`<div class="mgroup ${isOpen ? 'open' : ''}"><button class="mrow" data-tg="m:${key}"><span class="mn"><b>${MON[m]}</b><small>01.${mm} ~ ${endD}.${mm}</small></span>
      <span class="mv"><b class="in">${rp(x.i)}</b><b class="out">${rp(x.o)}</b><small>${rp(x.n)}</small></span><i class="chev">›</i></button>
      ${isOpen ? weeksOf(y, m, endD, fresh === `m:${key}`) : ''}</div>`);
  }
  return rows.join('');
}

function txView() {
  const { y, m } = mon, key = `${y}-${String(m + 1).padStart(2, '0')}`, isMonth = txTab === 'month';
  const nav = isMonth
    ? `<div class="mnav"><button data-yr="-1" aria-label="Tahun sebelumnya">‹</button><b>${y}</b><button data-yr="1" aria-label="Tahun berikutnya">›</button></div>`
    : `<div class="mnav"><button data-mo="-1" aria-label="Bulan sebelumnya">‹</button><b>${MON_FULL[m]} ${y}</b><button data-mo="1" aria-label="Bulan berikutnya">›</button></div>`;
  const tabs = [['day', 'Harian'], ['cal', 'Kalender'], ['month', 'Bulanan']];
  const x = isMonth ? inOut(`${y}-01-01`, `${y}-12-31`) : inOut(`${key}-01`, `${key}-31`);
  const body = txTab === 'day' ? dayView(key) : txTab === 'cal' ? calView(key) : monthView();
  return `${nav}<div class="tabs">${tabs.map(([k, l]) => `<button data-tab="${k}" class="${txTab === k ? 'on' : ''}">${l}</button>`).join('')}<i style="--i:${tabs.findIndex(t => t[0] === txTab)}"></i></div>
    ${sumRow(x)}${body}<button class="fab" data-new="1" aria-label="Transaksi baru">+</button>`;
}

function allBuckets() {
  const ds = [...book.transactions.map(t => t.date), ...book.entries.map(e => e.date.slice(0, 10))].sort(), end = new Date(), out = [];
  const f = ds[0] ?? today();
  let y = +f.slice(0, 4), m = +f.slice(5, 7) - 1;
  while (y < end.getFullYear() || (y === end.getFullYear() && m <= end.getMonth())) {
    out.push({ l: MON[m], a: ymd(new Date(y, m, 1)), b: ymd(new Date(y, m + 1, 0)) });
    if (++m > 11) { m = 0; y++; }
  }
  if (!out.length) out.push({ l: MON[end.getMonth()], a: ymd(new Date(end.getFullYear(), end.getMonth(), 1)), b: today() });
  return out.slice(-12);
}

const PIE_COL = ['#d32f2f', '#f08a24', '#f2b705', '#2e9e5b', '#1e88e5', '#8e44ad', '#9a9aa2'];
function pie() {
  const [a, b] = range(), agg = {};
  for (const t of book.transactions) if (t.kind === 'income' && t.status === 'berhasil' && t.date >= a && t.date <= b) {
    const o = (agg[t.category] ??= { n: 0, s: 0 }); o.n++; o.s += t.price;
  }
  const key = pieMode === 'count' ? 'n' : 's';
  let rows = Object.entries(agg).map(([c, o]) => ({ c, v: o[key] })).sort((x, y) => y.v - x.v);
  if (rows.length > 6) rows = [...rows.slice(0, 6), { c: 'Lainnya', v: rows.slice(6).reduce((s, r) => s + r.v, 0) }];
  const total = rows.reduce((s, r) => s + r.v, 0);
  const modes = `<div class="mini">${[['count', 'Jumlah'], ['sum', 'Nominal']].map(([k, l]) => `<button data-pm="${k}" class="${pieMode === k ? 'on' : ''}">${l}</button>`).join('')}</div>`;
  const head = `<div class="ph"><small>Kategori terlaris · ${LABEL[period]}</small>${modes}</div>`;
  if (!total) return `<div class="tile span2 pie">${head}<p class="empty">Belum ada penjualan pada periode ini.</p></div>`;
  const R = 50, C = 2 * Math.PI * R, GAP = rows.length > 1 ? 2.5 : 0;
  let off = 0;
  const arcs = rows.map((r, i) => {
    const len = r.v / total * C, dash = Math.max(0.5, len - GAP);
    const el = `<circle class="slice" data-pie="${i}" data-p="${Math.round(r.v / total * 100)}%" data-n="${esc(r.c)}" cx="70" cy="70" r="${R}" fill="none" stroke="${PIE_COL[i]}" stroke-width="20" stroke-dasharray="${dash.toFixed(2)} ${(C - dash).toFixed(2)}" stroke-dashoffset="${(-off).toFixed(2)}" style="--c:${C.toFixed(2)};animation-delay:${i * 80}ms"/>`;
    off += len; return el;
  }).join('');
  const dn = pieMode === 'count' ? String(total) : short(total), dl = pieMode === 'count' ? 'transaksi' : 'total';
  return `<div class="tile span2 pie" data-dn="${dn}" data-dl="${dl}">${head}
    <div class="pbody"><svg viewBox="0 0 140 140" role="img" aria-label="Diagram kategori terlaris"><g transform="rotate(-90 70 70)">${arcs}</g>
      <text class="pc-n" x="70" y="68" text-anchor="middle">${dn}</text><text class="pc-l" x="70" y="85" text-anchor="middle">${dl}</text></svg>
      <div class="plg">${rows.map((r, i) => `<button class="pl" data-pie="${i}"><i style="background:${PIE_COL[i]}"></i><span>${esc(r.c)}</span><em>${Math.round(r.v / total * 100)}%</em><small>${pieMode === 'count' ? `${r.v} transaksi` : rp(r.v)}</small></button>`).join('')}</div></div></div>`;
}

function openEdit(id) {
  const t = book.transactions.find(x => x.id === id);
  if (!t || !['pending', 'berhasil'].includes(t.status)) return;
  draft = { editId: id, kind: t.kind, date: t.date, time: t.time ?? '', price: String(t.price), cost: t.cost ? String(t.cost) : '', fee: t.fee ? String(t.fee) : '',
    note: t.product === t.category ? '' : t.product, category: t.category, method: t.method, source: t.source, paid: t.paid === false ? '0' : '1', field: 'price', pad: false };
  renderForm();
}

function closeSheet() {
  draft = null;
  const s = $('#sheet'); if (s.hidden) return;
  const my = ++tok; s.classList.add('out');
  setTimeout(() => { if (tok === my) { s.hidden = true; s.innerHTML = ''; s.classList.remove('out'); } }, 220);
}

function openDetail(id) {
  const t = book.transactions.find(x => x.id === id); if (!t) return;
  const unpaid = t.kind === 'income' && t.status === 'berhasil' && t.paid === false;
  const acts = [...(unpaid ? [['settle', 'Pembeli sudah bayar']] : []),
    ...(t.status === 'pending' ? [['berhasil', 'Tandai berhasil'], ['gagal', 'Gagal'], ['dibatalkan', 'Batalkan']]
      : t.status === 'berhasil' ? [t.kind === 'income' ? ['refund', 'Refund'] : ['dibatalkan', 'Batalkan transaksi']] : [])];
  const sale = t.kind === 'income' && t.cost > 0;
  const canEdit = ['pending', 'berhasil'].includes(t.status);
  const kv = [['Jenis', KIND[t.kind]], ['Waktu', `${t.date}${t.time ? ' · ' + t.time : ''}`], ['Kategori', t.category], ['Total', rp(t.price)],
    ...(sale ? [['Modal', rp(t.cost)], ['Biaya', rp(t.fee)], ['Untung', rp(t.price - t.cost - t.fee)], ['Sumber modal', SHORT[t.source]]] : []),
    [t.kind === 'transfer' ? 'Dari' : 'Aset', unpaid ? 'Piutang' : SHORT[t.kind === 'transfer' ? t.source : t.method]],
    ...(t.kind === 'transfer' ? [['Ke', SHORT[t.method]]] : []),
    ...(t.kind === 'income' ? [['Pembayaran', unpaid ? 'Pembeli belum menyerahkan uang' : 'Pembeli sudah menyerahkan uang']] : []),
    ['Status', t.status]];
  draft = null;
  const s = $('#sheet'); tok++; s.className = 'sheet bottom'; s.hidden = false;
  s.innerHTML = `<div class="box"><h3>${esc(t.product)}</h3>${kv.map(([k, v]) => `<div class="kv"><span>${k}</span><b>${esc(v)}</b></div>`).join('')}
    <div class="acts">${acts.map(([st, l]) => st === 'settle' ? `<button class="primary" data-settle="${t.id}">${l}</button>`
      : `<button class="${st === 'berhasil' ? 'primary' : ''}" data-tx="${t.id}" data-st="${st}">${l}</button>`).join('')}${canEdit ? `<button class="edit" data-edit="${t.id}">✎ Edit</button>` : ''}<button data-x="1">Tutup</button></div></div>`;
}

function setKind(k) {
  const d = draft;
  d.kind = k; d.field = 'price'; d.pad = true; d.paid = '1';
  d.category = k === 'transfer' ? 'Transfer' : k === 'saldo' ? 'Saldo' : book.categories[k][0];
  d.method = k === 'transfer' ? '1201' : '1101';
  d.source = k === 'transfer' ? '1101' : '1201';
}

function openForm(kind = 'income') {
  draft = { date: today(), time: nowHM(), price: '', cost: '', fee: '', note: '' };
  setKind(kind);
  renderForm();
}

function renderFormRaw() {
  const d = draft, k = d.kind;
  const num = (f) => `<div class="fr num ${d.field === f ? 'on' : ''}" data-f="${f}"><span>${LBL[f]}</span><b class="${d[f] ? '' : 'ph'}">${rp(Number(d[f] || 0))}</b></div>`;
  const row = (name) => `<div class="fr pk" data-pk="${name}"><span>${fieldLabel(name, k)}</span><b>${esc(pkLabel(name))}</b><i>›</i></div>`;
  const s = $('#sheet'); tok++; s.className = 'sheet full'; s.hidden = false;
  s.innerHTML = `<div class="sh-head"><button data-x="1" aria-label="Kembali">←</button><b>${d.editId ? 'Edit ' + TITLE[k] : TITLE[k]}</b><button class="primary" data-save="1">Simpan</button></div>
  ${k === 'saldo' ? '' : `<div class="kinds">${Object.entries(KIND).map(([v, l]) => `<button data-kind="${v}" class="${v === k ? 'on' : ''}">${l}</button>`).join('')}</div>`}
  <div class="fields">
    <label class="fr"><span>Waktu</span><input type="date" name="date" value="${d.date}"><input type="time" name="time" value="${d.time ?? ''}"></label>
    ${num('price')}${k === 'income' ? num('cost') + num('fee') : ''}
    ${k === 'income' || k === 'expense' ? row('category') : ''}
    ${k === 'transfer' ? row('source') + row('method') : row('method')}
    ${k === 'income' ? row('source') + `<div class="fr col"><span>Status</span>${pick('paid', [['1', 'Pembeli sudah menyerahkan uang'], ['0', 'Pembeli belum menyerahkan uang']], d.paid)}</div>` : ''}
    <label class="fr"><span>Catatan</span><input name="note" value="${esc(d.note)}" placeholder="Nama pelanggan / keterangan" autocomplete="off"></label>
  </div>
  <div id="pad" class="pad" ${d.pad ? '' : 'hidden'}><div class="pad-t"><b id="padt">${LBL[d.field]}</b><button type="button" data-key="done" aria-label="Tutup keypad">✕</button></div>
    <div class="keys">${KEYS.map(([c, l, x = '']) => `<button type="button" class="${x}" data-key="${c}">${l}</button>`).join('')}</div></div>`;
}

function updateNums() {
  document.querySelectorAll('#sheet .num').forEach(x => {
    const v = draft[x.dataset.f], b = x.querySelector('b');
    b.textContent = rp(Number(v || 0)); b.className = v ? '' : 'ph';
  });
}

function keypad(k) {
  const f = draft.field;
  if (k === 'calc') { openCalc(); return; }
  if (k === 'done') { draft.pad = false; $('#pad').hidden = true; return; }
  if (k === 'back') draft[f] = draft[f].slice(0, -1);
  else if (k === 'clear') draft[f] = '';
  else { const v = (draft[f] + k).replace(/^0+/, ''); if (v.length <= 12) draft[f] = v; }
  updateNums();
}

function saveDraft() {
  const d = draft, n = (k) => Number(d[k] || 0), c = { date: d.date, time: d.time, category: d.category, product: d.note };
  if (d.kind === 'saldo') {
    act(() => {
      if (n('price') <= 0) throw new Error('Nominal harus lebih dari 0');
      openAccount(book, { date: d.date, account: d.method, amount: n('price') });
      closeSheet();
    });
    return;
  }
  const t = d.kind === 'income' ? { ...c, kind: 'income', price: n('price'), cost: n('cost'), fee: n('fee'), method: d.method, source: d.source, status: 'berhasil', paid: d.paid === '1' }
    : d.kind === 'expense' ? { ...c, kind: 'expense', price: n('price'), method: d.method }
    : { ...c, kind: 'transfer', price: n('price'), source: d.source, method: d.method };
  act(() => {
    if (d.editId) editTransaction(book, d.editId, t); else addTransaction(book, t);
    view = 'tx'; if (!d.editId) txTab = 'day'; mon = { y: +d.date.slice(0, 4), m: +d.date.slice(5, 7) - 1 };
    closeSheet();
  });
}

let calc = null;
const CK = [['C', 'C', 'k-alt'], ['back', '⌫', 'k-alt'], ['÷', '÷', 'k-op'], ['×', '×', 'k-op'], ['7'], ['8'], ['9'], ['-', '−', 'k-op'],
  ['4'], ['5'], ['6'], ['+', '+', 'k-op'], ['1'], ['2'], ['3'], ['=', '=', 'k-op'], ['0'], ['000'], ['use', 'Pakai', 'k-done k-w']];

function openCalc() {
  calc = { expr: draft[draft.field] };
  const c = $('#calc'); c.hidden = false;
  c.innerHTML = `<div class="box"><div class="calc-h"><b>Kalkulator · ${LBL[draft.field]}</b><button type="button" data-c="x" aria-label="Tutup">✕</button></div>
    <div class="calc-d"><small id="cx"></small><b id="cr"></b></div>
    <div class="ckeys">${CK.map(([k, l = k, x = '']) => `<button type="button" class="${x}" data-c="${k}">${l}</button>`).join('')}</div></div>`;
  showCalc();
}

function closeCalc() { calc = null; const c = $('#calc'); c.hidden = true; c.innerHTML = ''; }

function calcResult() {
  const r = Math.round(evalExpr(calc.expr));
  if (r < 0) throw new Error('Hasil tidak boleh negatif');
  if (String(r).length > 12) throw new Error('Angka terlalu besar');
  return r;
}

function showCalc() {
  let r; try { r = rp(Math.round(evalExpr(calc.expr))); } catch (e) { r = e.message; }
  $('#cx').textContent = fmtExpr(calc.expr) || '0';
  $('#cr').textContent = `= ${r}`;
}

function calcKey(k) {
  try {
    if (k === 'x') { closeCalc(); return; }
    if (k === 'use') { draft[draft.field] = String(calcResult()).replace(/^0$/, ''); updateNums(); closeCalc(); return; }
    calc.expr = k === '=' ? String(calcResult()) : pressKey(calc.expr, k);
    showCalc();
  } catch (e) { toast(e.message); }
}

const TITLE = { ...KIND, saldo: 'Tambah saldo' };
const fieldLabel = (name, k) => name === 'category' ? 'Kategori'
  : name === 'source' ? (k === 'transfer' ? 'Dari' : 'Sumber modal')
  : { income: 'Masuk ke', expense: 'Dibayar dari', transfer: 'Ke', saldo: 'Akun' }[k];
const pkLabel = (name) => name === 'category' ? draft.category : SHORT[draft[name]];
const syncRows = () => document.querySelectorAll('#sheet .pk').forEach(r => { r.querySelector('b').textContent = pkLabel(r.dataset.pk); });
let pkName = null;

function pickerOpts(name) {
  if (name === 'category') return book.categories[draft.kind].map(c => ({ v: c, l: c, del: true }));
  return Object.values(book.accounts).filter(a => a.type === 'asset' && a.code !== '1301')
    .map(a => ({ v: a.code, l: SHORT[a.code], s: rp(balance(book, a.code)), del: a.code.startsWith('14') }));
}

function renderPicker() {
  const c = $('#pick'), cur = pkName === 'category' ? draft.category : draft[pkName];
  c.hidden = false;
  c.innerHTML = `<div class="box"><div class="calc-h"><b>${fieldLabel(pkName, draft.kind)}</b><button type="button" data-pkx="1" aria-label="Tutup">✕</button></div>
    <div class="plist">${pickerOpts(pkName).map(o => `<div class="popt ${o.v === cur ? 'on' : ''}"><button type="button" data-pv="${esc(o.v)}"><span>${esc(o.l)}</span>${o.s ? `<small>${o.s}</small>` : ''}</button>${o.del ? `<button type="button" class="pdel" data-pd="${esc(o.v)}" aria-label="Hapus">✕</button>` : ''}</div>`).join('')}</div>
    <div class="addcat"><input name="newopt" maxlength="20" placeholder="${pkName === 'category' ? 'Kategori baru' : 'Akun baru, mis. DANA'}" autocomplete="off"><button type="button" data-padd="1">Tambah</button></div></div>`;
}
const openPicker = (name) => { pkName = name; renderPicker(); };
function closePicker() { pkName = null; const c = $('#pick'); c.hidden = true; c.innerHTML = ''; }

const emptyHint = () => book.entries.length || demo ? '' :
  `<div class="hint"><b>Belum ada data</b><small>Mulai dari menu Kas (Tambah saldo), atau lihat tampilannya dengan data contoh.</small><button data-demo="1">Lihat data contoh</button></div>`;

function renderForm() {
  const sc = $('#sheet .fields')?.scrollTop ?? 0;
  renderFormRaw();
  const f = $('#sheet .fields'); if (f) f.scrollTop = sc;
}

function kasView() {
  const [a, b] = range(), p = profitLoss(book, a, b);
  const seg = [['day', 'Hari'], ['week', 'Minggu'], ['month', 'Bulan'], ['year', 'Tahun'], ['all', 'Semua']]
    .map(([k, l]) => `<button data-period="${k}" class="${period === k ? 'on' : ''}">${l}</button>`).join('');
  const accs = Object.values(book.accounts).filter(x => x.type === 'asset' && x.code !== '1301');
  const tot = Math.max(1, accs.reduce((s, x) => s + Math.max(0, balance(book, x.code)), 0));
  const byCat = {};
  for (const t of book.transactions)
    if (t.kind === 'income' && t.status === 'berhasil' && t.date >= a && t.date <= b) byCat[t.category] = (byCat[t.category] ?? 0) + t.price - t.cost - t.fee;
  const cats = Object.entries(byCat).sort((x, y) => y[1] - x[1]).slice(0, 5), top = Math.max(1, ...cats.map(c => Math.abs(c[1])));
  const unpaid = book.transactions.filter(t => t.kind === 'income' && t.status === 'berhasil' && t.paid === false).reverse();
  return `<div class="bento">${saldoHero()}</div>
  <h3>Akun</h3>
  <div class="items accs">${accs.map(x => { const v = balance(book, x.code); return `<div class="acc"><span class="ic">${ico(ACC_ICON[x.code] ?? 'wallet')}</span>
    <div class="an"><b>${esc(SHORT[x.code])}</b><div class="bar"><i style="width:${Math.round(Math.max(0, v) / tot * 100)}%"></i></div></div><strong>${rp(v)}</strong></div>`; }).join('')}</div>
  <h3>Keuntungan</h3>
  <div class="seg">${seg}</div>
  <div class="bento">
    <div class="tile ink span2"><small>Untung bersih · ${LABEL[period]}</small><b>${rp(p.net)}</b>
      <div class="kvs"><span>Harga jual</span><em>${rp(p.revenue)}</em><span>Modal</span><em>${rp(p.cogs)}</em><span>Biaya &amp; pengeluaran</span><em>${rp(p.expense)}</em></div></div>
    <div class="tile span2 cbars"><small>Untung penjualan per kategori</small>${cats.map(([n, v]) => `<div class="cb"><div><span>${esc(n)}</span><b>${rp(v)}</b></div><div class="bar"><i style="width:${Math.round(Math.abs(v) / top * 100)}%"></i></div></div>`).join('') || '<p class="empty">Belum ada penjualan pada periode ini.</p>'}</div>
    ${pie()}
  </div>
  <h3>Piutang · ${rp(balance(book, '1301'))}</h3>
  ${unpaid.map(t => `<div class="row"><div><b>${esc(t.product)}</b><small>${t.date} · ${esc(t.category)}</small></div><div class="side"><b>${rp(t.price)}</b><button class="primary" data-settle="${t.id}">Sudah bayar</button></div></div>`).join('') || '<p class="empty">Tidak ada pembeli yang belum bayar.</p>'}
  <h3>Kelola</h3>
  <div class="bento"><button class="tile act" data-newsaldo="1"><span class="ic">${ico('plus')}</span><b>Tambah saldo / modal</b></button></div>
  <form id="af" class="form"><small>Tambah akun baru</small><div class="addcat"><input name="name" maxlength="20" placeholder="Mis. DANA, BRI, Deposit Server B" required autocomplete="off"><button>Tambah</button></div></form>`;
}

function render() {
  if (!book) return;
  $('#main').className = ''; $('#main').innerHTML = (demo ? '<div class="demo"><span>Mode contoh: data tidak disimpan</span><button data-demoexit="1">Keluar</button></div>' : '') + { home, tx: txView, kas: kasView }[view]();
  document.querySelectorAll('nav button').forEach(b => b.classList.toggle('on', b.dataset.v === view));
}

async function act(fn) {
  try { fn(); if (storage) await saveSnapshot(snapshot(book)); render(); } catch (e) { toast(e.message); }
}

document.addEventListener('click', e => {
  if (!book) return;
  if (e.target.closest('#sheet.out')) return;
  const ps = e.target.closest('[data-pie]');
  if (ps) {
    const w = ps.closest('.pie'), i = ps.dataset.pie, sl = w.querySelector(`.slice[data-pie="${i}"]`), on = !sl.classList.contains('sel');
    w.querySelectorAll('[data-pie]').forEach(x => x.classList.toggle('sel', on && x.dataset.pie === i));
    w.classList.toggle('has', on);
    w.querySelector('.pc-n').textContent = on ? sl.dataset.p : w.dataset.dn;
    w.querySelector('.pc-l').textContent = on ? sl.dataset.n : w.dataset.dl;
    return;
  }
  const g = e.target.closest('.grp');
  if (g) {
    g.closest('svg').querySelectorAll('.grp').forEach(x => x.classList.toggle('sel', x === g));
    g.closest('.chart').querySelector('.readout').textContent = g.dataset.t;
    return;
  }
  const nf = e.target.closest('.num');
  if (nf && draft) {
    draft.field = nf.dataset.f; draft.pad = true;
    document.querySelectorAll('#sheet .num').forEach(x => x.classList.toggle('on', x === nf));
    $('#pad').hidden = false; $('#padt').textContent = LBL[draft.field];
    document.activeElement?.blur();
    return;
  }
  if (e.target.id === 'calc') { closeCalc(); return; }
  if (e.target.id === 'pick') { closePicker(); return; }
  const pr = e.target.closest('.pk');
  if (pr && draft) { openPicker(pr.dataset.pk); return; }
  const sh = $('#sheet');
  if (e.target === sh && sh.classList.contains('bottom')) { closeSheet(); return; }
  const t = e.target.closest('button'); if (!t) return;
  const d = t.dataset;
  if (d.pick !== undefined) {
    const p = t.closest('.pick'), inp = p.querySelector('input');
    inp.value = d.pick;
    if (draft && t.closest('#sheet')) draft[inp.name] = d.pick;
    p.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === t));
  }
  else if (d.key) keypad(d.key);
  else if (d.kind) { setKind(d.kind); renderForm(); }
  else if (d.c !== undefined) calcKey(d.c);
  else if (d.tab) { txTab = d.tab; render(); }
  else if (d.yr) { mon.y += Number(d.yr); render(); }
  else if (d.tg) { if (openKeys.has(d.tg)) openKeys.delete(d.tg); else { openKeys.add(d.tg); fresh = d.tg; } render(); fresh = ''; $('#main').classList.add('still'); }
  else if (d.day) { selDay = d.day; render(); $('#main').classList.add('still'); }
  else if (d.pm) { pieMode = d.pm; render(); $('#main').classList.add('still'); }
  else if (d.edit) { t.classList.add('pressed'); const id = d.edit; setTimeout(() => openEdit(id), 220); }
  else if (d.pkx) closePicker();
  else if (d.pv !== undefined) { draft[pkName] = d.pv; closePicker(); syncRows(); }
  else if (d.pd !== undefined) act(() => {
    if (pkName === 'category') { removeCategory(book, draft.kind, d.pd); if (draft.category === d.pd) draft.category = book.categories[draft.kind][0]; }
    else { removeAccount(book, d.pd); for (const f of ['method', 'source']) if (draft[f] === d.pd) draft[f] = '1101'; }
    renderPicker(); syncRows();
  });
  else if (d.padd) {
    const v = $('#pick [name=newopt]').value;
    act(() => { if (pkName === 'category') draft.category = addCategory(book, draft.kind, v); else draft[pkName] = addAccount(book, v); closePicker(); syncRows(); });
  }
  else if (d.settle) act(() => { settleTransaction(book, d.settle, today()); closeSheet(); });
  else if (d.newsaldo) openForm('saldo');
  else if (d.demo) { book = demoBook(); demo = true; storage = false; view = 'home'; render(); }
  else if (d.demoexit) location.reload();
  else if (d.save) saveDraft();
  else if (d.x) closeSheet();
  else if (d.new) openForm();
  else if (d.open) openDetail(d.open);
  else if (d.mo) { selDay = null; mon.m += Number(d.mo); if (mon.m < 0) { mon.m = 11; mon.y--; } if (mon.m > 11) { mon.m = 0; mon.y++; } render(); }
  else if (d.v) { view = d.v; render(); }
  else if (d.period) { period = d.period; render(); }
  else if (d.tx) act(() => { setStatus(book, d.tx, d.st, today()); closeSheet(); });
});

document.addEventListener('input', e => {
  if (draft && (e.target.name === 'note' || e.target.name === 'date' || e.target.name === 'time')) draft[e.target.name] = e.target.value;
});
document.addEventListener('focusin', e => {
  if (draft && e.target.matches('#sheet input')) { draft.pad = false; $('#pad').hidden = true; }
});
document.addEventListener('submit', e => {
  e.preventDefault(); if (!book) return;
  const f = Object.fromEntries(new FormData(e.target));
  act(() => addAccount(book, f.name));
});

(async () => {
  $('#date').textContent = new Date().toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long' });
  try {
    let s = null;
    try { s = await loadSnapshot(); } catch { storage = false; toast('Penyimpanan perangkat tidak tersedia. Data hanya sementara.'); }
    book = s ? restore(s) : createBook();
    navigator.storage?.persist?.();
    render();
  } catch (e) {
    $('#main').innerHTML = `<p class="empty">Data gagal dimuat (${esc(e.message)}). Aplikasi dikunci agar data lama tidak tertimpa.</p>`;
  }
})();
if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => {});
