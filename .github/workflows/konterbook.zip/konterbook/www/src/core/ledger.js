import { assertRupiah } from './money.js';
import { CHART } from './accounts.js';

const DEBIT_NORMAL = new Set(['asset', 'cogs', 'expense']);

export function createBook() {
  const accounts = {};
  for (const [code, name, type] of CHART) accounts[code] = { code, name, type };
  return { accounts, entries: [], reversedBy: {}, audit: [], transactions: [], categories: defaultCategories(), seq: 0 };
}

const log = (book, action, detail) =>
  book.audit.push({ at: new Date().toISOString(), action, detail });

export function balance(book, code) {
  const acc = book.accounts[code];
  if (!acc) throw new Error(`Akun ${code} tidak ada`);
  let d = 0, c = 0;
  for (const e of book.entries)
    for (const l of e.lines) if (l.account === code) { d += l.debit; c += l.credit; }
  return DEBIT_NORMAL.has(acc.type) ? d - c : c - d;
}

export function isBalanced(book) {
  let d = 0, c = 0;
  for (const e of book.entries) for (const l of e.lines) { d += l.debit; c += l.credit; }
  return d === c;
}

// Satu-satunya pintu menulis ke buku besar. Entri tidak pernah diubah/dihapus.
export function postEntry(book, { date, memo = '', ref = null, lines, allowNegative = false, reversalOf = null }) {
  if (!/^\d{4}-\d{2}-\d{2}/.test(date ?? '')) throw new Error('Tanggal tidak valid');
  if (!Array.isArray(lines) || lines.length < 2) throw new Error('Jurnal minimal 2 baris');
  if (ref && book.entries.some(e => e.ref === ref && !e.reversalOf && !book.reversedBy[e.id]))
    throw new Error(`Transaksi duplikat: ${ref}`);

  let td = 0, tc = 0;
  const clean = lines.map(({ account, debit = 0, credit = 0 }) => {
    if (!book.accounts[account]) throw new Error(`Akun ${account} tidak ada`);
    assertRupiah(debit, 'debit');
    assertRupiah(credit, 'kredit');
    if (debit < 0 || credit < 0 || (debit > 0) === (credit > 0))
      throw new Error('Tiap baris harus punya tepat satu sisi bernilai > 0');
    td += debit; tc += credit;
    return Object.freeze({ account, debit, credit });
  });
  if (td !== tc) throw new Error(`Jurnal tidak seimbang: debit ${td} != kredit ${tc}`);

  if (!allowNegative) {
    for (const code of new Set(clean.map(l => l.account))) {
      const acc = book.accounts[code];
      if (acc.type !== 'asset') continue;
      const delta = clean.filter(l => l.account === code).reduce((s, l) => s + l.debit - l.credit, 0);
      if (balance(book, code) + delta < 0) throw new Error(`Saldo ${acc.name} tidak cukup`);
    }
  }

  const entry = Object.freeze({
    id: `JE-${String(++book.seq).padStart(6, '0')}`,
    date, memo, ref, reversalOf, lines: Object.freeze(clean),
  });
  book.entries.push(entry);
  log(book, 'POST', { id: entry.id, ref, memo });
  return entry;
}

export function reverseEntry(book, id, { date, reason, allowNegative = false }) {
  const orig = book.entries.find(e => e.id === id);
  if (!orig) throw new Error(`Jurnal ${id} tidak ditemukan`);
  if (orig.reversalOf) throw new Error('Jurnal pembalik tidak dapat dibalik lagi');
  if (book.reversedBy[id]) throw new Error(`Jurnal ${id} sudah dibalik`);
  if (!reason) throw new Error('Alasan pembalikan wajib diisi');
  const rev = postEntry(book, {
    date, allowNegative, reversalOf: id, memo: `Pembalikan ${id}: ${reason}`,
    lines: orig.lines.map(l => ({ account: l.account, debit: l.credit, credit: l.debit })),
  });
  book.reversedBy[id] = rev.id;
  log(book, 'REVERSE', { id, by: rev.id, reason });
  return rev;
}

export function openAccount(book, { date, account, amount }) {
  return postEntry(book, {
    date, memo: `Saldo awal ${book.accounts[account]?.name ?? account}`,
    lines: [{ account, debit: amount }, { account: '3101', credit: amount }],
  });
}

// Penjualan berhasil. Untung bersih = price - cost - fee.
export function recordSale(book, { date, ref, product, cost, price, fee = 0, payTo = '1101', source = '1201', allowLoss = false, allowNegative = false }) {
  assertRupiah(cost, 'harga modal'); assertRupiah(price, 'harga jual'); assertRupiah(fee, 'biaya tambahan');
  if (cost <= 0 || price <= 0 || fee < 0) throw new Error('Nominal harus positif');
  if (price < cost + fee && !allowLoss) throw new Error('Harga jual di bawah modal + biaya');
  const lines = [
    { account: payTo, debit: price },
    { account: '4101', credit: price },
    { account: '5101', debit: cost },
    ...(fee ? [{ account: '6101', debit: fee }] : []),
    { account: source, credit: cost + fee },
  ];
  return postEntry(book, { date, ref, memo: `Penjualan ${product}`, lines, allowNegative });
}

// Transfer internal: bukan omzet, bukan untung.
export function transfer(book, { date, from, to, amount, ref = null, allowNegative = false }) {
  if (from === to) throw new Error('Akun asal dan tujuan harus berbeda');
  return postEntry(book, {
    date, ref, allowNegative, memo: `Transfer ${from} ke ${to}`,
    lines: [{ account: to, debit: amount }, { account: from, credit: amount }],
  });
}

export function profitLoss(book, from, to) {
  const s = { revenue: 0, cogs: 0, expense: 0 };
  for (const e of book.entries) {
    const day = e.date.slice(0, 10);
    if (day < from || day > to) continue;
    for (const l of e.lines) {
      const t = book.accounts[l.account].type;
      if (t === 'revenue') s.revenue += l.credit - l.debit;
      else if (t in s) s[t] += l.debit - l.credit;
    }
  }
  const gross = s.revenue - s.cogs;
  return { ...s, gross, net: gross - s.expense };
}

export const snapshot = (book) => JSON.stringify(book);
export function restore(json) {
  const book = JSON.parse(json);
  book.transactions ??= [];
  book.categories ??= defaultCategories();
  if (!isBalanced(book)) throw new Error('Backup rusak: jurnal tidak seimbang');
  return book;
}

// ---- Transaksi bertatus. kind: income | expense | transfer. Hanya 'berhasil' masuk jurnal. ----
export const CATEGORY_LIST = ['Pulsa', 'Paket Data', 'Top-up Game', 'Voucher Game', 'E-Wallet', 'Token Listrik', 'PPOB', 'Lainnya'];
export const EXPENSE_CATS = ['Operasional', 'Sewa', 'Listrik', 'Internet', 'Gaji', 'Transport', 'Lainnya'];
const NEXT = { pending: ['berhasil', 'gagal', 'dibatalkan'] };

function posting(book, tx, date) {
  const base = { date, ref: tx.id }, pay = tx.paid === false ? '1301' : tx.method;
  if (tx.kind === 'expense')
    return postEntry(book, { ...base, memo: `Pengeluaran ${tx.product}`, lines: [{ account: '6101', debit: tx.price }, { account: tx.method, credit: tx.price }] });
  if (tx.kind === 'transfer') return transfer(book, { ...base, from: tx.source, to: tx.method, amount: tx.price });
  if (tx.cost > 0) return recordSale(book, { ...base, product: tx.product, cost: tx.cost, price: tx.price, fee: tx.fee, payTo: pay, source: tx.source });
  return postEntry(book, { ...base, memo: `Pendapatan ${tx.product}`, lines: [{ account: pay, debit: tx.price }, { account: '4101', credit: tx.price }] });
}

function normalize(t) {
  const kind = t.kind ?? 'income';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(t.date ?? '')) throw new Error('Tanggal tidak valid');
  if (t.time && !/^([01]\d|2[0-3]):[0-5]\d$/.test(t.time)) throw new Error('Jam tidak valid');
  if (!['income', 'expense', 'transfer'].includes(kind)) throw new Error('Jenis transaksi tidak valid');
  const cost = kind === 'income' ? t.cost ?? 0 : 0, fee = kind === 'income' ? t.fee ?? 0 : 0;
  for (const [k, v] of [['nominal', t.price], ['harga modal', cost], ['biaya', fee]]) assertRupiah(v, k);
  if (t.price <= 0 || cost < 0 || fee < 0) throw new Error('Nominal harus lebih dari 0');
  if (kind === 'income' && cost === 0 && fee > 0) throw new Error('Biaya tambahan butuh harga modal');
  return {
    date: t.date, time: t.time ?? '', kind, product: (t.product ?? '').trim() || t.category || 'Transaksi', category: t.category ?? 'Lainnya',
    cost, price: t.price, fee, paid: kind === 'income' ? t.paid !== false : true, method: t.method ?? '1101', source: t.source ?? '1201',
  };
}

export function addTransaction(book, t) {
  const kind = t.kind ?? 'income', status = t.status ?? (kind === 'income' ? 'pending' : 'berhasil');
  const f = normalize(t);
  if (!['pending', 'berhasil', 'gagal'].includes(status) || (f.kind !== 'income' && status !== 'berhasil')) throw new Error('Status awal tidak valid');
  const tx = { id: `TX-${String(book.transactions.length + 1).padStart(6, '0')}`, ...f, status: 'pending', note: t.note ?? '', entryId: null };
  book.transactions.push(tx);
  try { if (status !== 'pending') setStatus(book, tx.id, status, t.date); }
  catch (e) { book.transactions.pop(); throw e; }
  log(book, 'TX_ADD', { id: tx.id });
  return tx;
}

// Koreksi: jurnal lama dibalik (pada tanggal aslinya, supaya laporan harian tetap benar), lalu diposting ulang dengan data baru.
export function editTransaction(book, id, patch) {
  const tx = book.transactions.find(x => x.id === id);
  if (!tx) throw new Error('Transaksi tidak ditemukan');
  if (!['pending', 'berhasil'].includes(tx.status)) throw new Error('Transaksi ini sudah ditutup dan tidak bisa diedit');
  const next = { ...tx, ...normalize({ ...tx, ...patch }) };
  const assets = Object.values(book.accounts).filter(a => a.type === 'asset');
  const neg0 = new Set(assets.filter(a => balance(book, a.code) < 0).map(a => a.code));
  atomic(book, () => {
    if (tx.entryId) {
      for (const eid of [tx.settleId, tx.entryId].filter(Boolean)) {
        const e = book.entries.find(x => x.id === eid);
        reverseEntry(book, eid, { date: e.date, reason: `Koreksi ${tx.id}`, allowNegative: true });
      }
      next.entryId = null; next.settleId = null;
    }
    if (next.status === 'berhasil') next.entryId = posting(book, next, next.date).id;
    for (const a of assets) if (balance(book, a.code) < 0 && !neg0.has(a.code)) throw new Error(`Saldo ${a.name} tidak cukup`);
  });
  Object.assign(tx, next);
  log(book, 'TX_EDIT', { id });
  return tx;
}

export function setStatus(book, id, status, date) {
  const tx = book.transactions.find(x => x.id === id);
  if (!tx) throw new Error('Transaksi tidak ditemukan');
  const allowed = tx.status === 'berhasil' ? (tx.kind === 'income' ? ['refund'] : ['dibatalkan']) : NEXT[tx.status];
  if (!allowed?.includes(status)) throw new Error(`Status ${tx.status} tidak bisa menjadi ${status}`);
  if (status === 'berhasil') tx.entryId = posting(book, tx, date).id;
  else if (tx.entryId) atomic(book, () => {
    const reason = `${status} ${tx.id}`;
    if (tx.settleId) reverseEntry(book, tx.settleId, { date, reason });
    reverseEntry(book, tx.entryId, { date, reason });
  });
  tx.status = status;
  log(book, 'TX_STATUS', { id, status });
  return tx;
}

// ---- Kategori kustom (tersimpan di buku, ikut backup). Transaksi lama tetap menyimpan nama kategorinya. ----
function defaultCategories() { return { income: [...CATEGORY_LIST], expense: [...EXPENSE_CATS] }; }

export function addCategory(book, kind, name) {
  const list = book.categories[kind], n = String(name ?? '').trim().replace(/\s+/g, ' ');
  if (!list) throw new Error('Jenis kategori tidak valid');
  if (!n) throw new Error('Nama kategori wajib diisi');
  if (n.length > 20) throw new Error('Nama kategori maksimal 20 huruf');
  if (list.some(c => c.toLowerCase() === n.toLowerCase())) throw new Error('Kategori sudah ada');
  list.push(n);
  log(book, 'CAT_ADD', { kind, name: n });
  return n;
}

export function removeCategory(book, kind, name) {
  const list = book.categories[kind], i = list ? list.indexOf(name) : -1;
  if (i < 0) throw new Error('Kategori tidak ditemukan');
  if (list.length === 1) throw new Error('Minimal harus ada satu kategori');
  list.splice(i, 1);
  log(book, 'CAT_DEL', { kind, name });
}

// ---- Pembayaran (piutang) dan akun kustom ----
export const ACCOUNT_SHORT = { 1101: 'Tunai', 1102: 'Bank', 1201: 'Deposit Pulsa', 1202: 'Deposit PPOB', 1203: 'E-Wallet', 1301: 'Piutang' };

function atomic(book, fn) {
  const keep = { n: book.entries.length, a: book.audit.length, seq: book.seq, rev: { ...book.reversedBy } };
  try { return fn(); } catch (e) {
    book.entries.length = keep.n; book.audit.length = keep.a; book.seq = keep.seq; book.reversedBy = keep.rev;
    throw e;
  }
}

// Pembeli belum bayar = penjualan tercatat ke Piutang. Pelunasan memindahkan Piutang ke akun tujuan.
export function settleTransaction(book, id, date) {
  const tx = book.transactions.find(x => x.id === id);
  if (!tx) throw new Error('Transaksi tidak ditemukan');
  if (tx.kind !== 'income' || tx.status !== 'berhasil' || tx.paid !== false) throw new Error('Transaksi ini tidak menunggu pembayaran');
  if (tx.method === '1301') throw new Error('Pilih akun tujuan selain Piutang');
  const e = postEntry(book, { date, ref: `${tx.id}-LUNAS`, memo: `Pelunasan ${tx.product}`,
    lines: [{ account: tx.method, debit: tx.price }, { account: '1301', credit: tx.price }] });
  tx.paid = true; tx.settleId = e.id;
  log(book, 'TX_PAID', { id });
  return tx;
}

export function addAccount(book, name) {
  const n = String(name ?? '').trim().replace(/\s+/g, ' ');
  if (!n) throw new Error('Nama akun wajib diisi');
  if (n.length > 20) throw new Error('Nama akun maksimal 20 huruf');
  const taken = [...Object.values(ACCOUNT_SHORT), ...Object.values(book.accounts).map(a => a.name)];
  if (taken.some(x => x.toLowerCase() === n.toLowerCase())) throw new Error('Nama akun sudah ada');
  let i = 1; while (book.accounts[`14${String(i).padStart(2, '0')}`]) i++;
  const code = `14${String(i).padStart(2, '0')}`;
  book.accounts[code] = { code, name: n, type: 'asset' };
  log(book, 'ACC_ADD', { code, name: n });
  return code;
}

export function removeAccount(book, code) {
  if (!book.accounts[code] || !code.startsWith('14')) throw new Error('Akun bawaan tidak bisa dihapus');
  if (book.entries.some(e => e.lines.some(l => l.account === code))) throw new Error('Akun sudah punya riwayat, tidak bisa dihapus');
  if (book.transactions.some(t => t.method === code || t.source === code)) throw new Error('Akun dipakai transaksi, tidak bisa dihapus');
  delete book.accounts[code];
  log(book, 'ACC_DEL', { code });
}
