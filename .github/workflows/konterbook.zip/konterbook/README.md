# KonterBook (nama sementara)

Aplikasi akuntansi konter digital, offline-first. JavaScript murni (tanpa build), jalan di browser, HP, dan bisa dibungkus jadi APK.

## Struktur
- `www/` : aplikasi (index.html, app.js, style.css, manifest, sw.js)
  - `www/src/core/` : money.js (rupiah integer), accounts.js (bagan akun), ledger.js (double-entry, transaksi bertatus)
  - `www/src/db/idb.js` : penyimpanan IndexedDB di perangkat
- `test/` : tes otomatis. `capacitor.config.json` : pengaturan APK.

## Aturan data
Jurnal wajib seimbang; nominal integer; tidak ada hapus/ubah (koreksi/refund = jurnal pembalik); saldo aset tidak boleh negatif; hanya status Berhasil masuk jurnal (Pending/Gagal/Batal tidak). Semua angka dashboard dihitung dari jurnal.

## Jalankan di browser / HP
`npm run serve`, buka alamat yang tampil. Dari HP, buka alamat IP laptop (satu Wi-Fi). Jangan buka index.html langsung (modul JS butuh server).

## Jadi APK (Capacitor)
Prasyarat: Node 20+, JDK 21, Android Studio.
1. `npm install`
2. `npm run apk:init` (sekali saja)
3. `npm run apk:sync` (setiap `www/` berubah)
4. `npm run apk:open`, lalu di Android Studio: Build > Build APK(s)

Data tersimpan di perangkat (IndexedDB). Backup/restore menyusul di Tahap 5.

## Tes
`npm test` (Node 18+, tanpa install).

## File tunggal untuk dilihat langsung
`npm run build:single` menghasilkan `dist/konterbook.html` (satu file, tanpa server). Buka dengan klik; tombol "Lihat data contoh" di Dashboard mengisi data contoh yang tidak disimpan.
