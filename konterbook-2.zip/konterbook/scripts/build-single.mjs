// Menggabungkan www/ menjadi SATU file HTML mandiri: dist/konterbook.html (bisa diklik/dibuka langsung).
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
const www = (p) => readFileSync(new URL(`../www/${p}`, import.meta.url), 'utf8');
const strip = (s) => s.replace(/^import[^\n]*\n/gm, '').replace(/^export\s+(?=(?:async\s+)?(?:function|const|let|class)\b)/gm, '');
const files = ['src/core/money.js', 'src/core/accounts.js', 'src/core/notes.js', 'src/core/calc.js', 'src/core/ledger.js', 'src/core/report.js', 'src/core/demo.js', 'src/db/idb.js', 'src/core/receipt.js', 'src/core/attach.js', 'src/core/ocr.js', 'src/db/files.js', 'app.js'];
const js = 'const rp = formatRupiah;\n' + files.map(f => `// ---- ${f}\n${strip(www(f))}`).join('\n').replace(/^if \('serviceWorker'[^\n]*\n?/m, '');
const css = www('style.css');
const html = www('index.html')
  .replace(/<link rel="(?:manifest|icon)"[^>]*>\n?/g, '')
  .replace('<link rel="stylesheet" href="style.css">', () => `<style>\n${css}\n</style>`)
  .replace('<script type="module" src="app.js"></script>', () => `<script type="module">\n${js}\n</script>`);
mkdirSync(new URL('../dist/', import.meta.url), { recursive: true });
writeFileSync(new URL('../dist/konterbook.html', import.meta.url), html);
console.log('OK', (html.length / 1024).toFixed(1) + ' KB');
