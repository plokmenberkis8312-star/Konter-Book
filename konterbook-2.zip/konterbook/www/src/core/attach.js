// Lampiran gambar pada transaksi. Hanya METADATA yang disimpan di buku (tx.files); isi gambar ada di db/files.js.
// Lampiran bukan bagian jurnal, jadi boleh ditambah/dihapus bebas tanpa menyentuh akuntansi.
export const MAX_FILES = 6;
const atClean = (f) => ({
  id: String(f.id), name: String(f.name ?? 'gambar').slice(0, 60), w: Math.max(0, f.w | 0), h: Math.max(0, f.h | 0), size: Math.max(0, f.size | 0),
  at: f.at ?? new Date().toISOString(), text: String(f.text ?? '').slice(0, 3000),
});

export const newFileId = () => `F${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
export const filesOf = (tx) => Array.isArray(tx?.files) ? tx.files : [];
export const fileText = (tx) => filesOf(tx).map(f => f.text ?? '').join(' ');

export function setFiles(book, txId, files) {
  const tx = book.transactions.find(x => x.id === txId);
  if (!tx || tx.deleted) throw new Error('Transaksi tidak ditemukan');
  const list = files.map(atClean);
  if (list.length > MAX_FILES) throw new Error(`Maksimal ${MAX_FILES} gambar per transaksi`);
  if (new Set(list.map(f => f.id)).size !== list.length) throw new Error('Gambar ganda');
  tx.files = list;
  return tx;
}

// Semua id gambar yang masih dirujuk buku (termasuk transaksi yang disembunyikan).
export const fileIdsInUse = (book) => new Set(book.transactions.flatMap(t => filesOf(t).map(f => f.id)));
