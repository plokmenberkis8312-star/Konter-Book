// Mesin baca teks dari gambar. Berjalan DI PERANGKAT (gambar tidak dikirim ke mana pun); hanya file mesinnya
// diunduh sekali dari CDN. Tanpa internet, pengguna tetap bisa melampirkan gambar dan mengisi manual / menempel teks.
const OCR_SRC = 'https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js';
let ocrLib = null;

function ocrLoad() {
  if (globalThis.Tesseract) return Promise.resolve(globalThis.Tesseract);
  return ocrLib ??= new Promise((res, rej) => {
    const s = document.createElement('script'); s.src = OCR_SRC;
    s.onload = () => globalThis.Tesseract ? res(globalThis.Tesseract) : (ocrLib = null, rej(new Error('Mesin baca gambar tidak lengkap')));
    s.onerror = () => { ocrLib = null; s.remove(); rej(new Error('Mesin baca gambar belum bisa dimuat. Hubungkan internet sekali, atau tempel teksnya manual.')); };
    document.head.appendChild(s);
  });
}

// onProgress(teks, 0..1). Mengembalikan teks hasil bacaan.
export async function readImageText(blob, onProgress = () => {}) {
  const T = await ocrLoad();
  onProgress('Menyiapkan mesin…', 0);
  const w = await T.createWorker('eng', 1, { logger: (m) => { if (typeof m.progress === 'number') onProgress(m.status === 'recognizing text' ? 'Membaca teks…' : 'Menyiapkan mesin…', m.progress); } });
  try { return (await w.recognize(blob)).data.text ?? ''; }
  finally { await w.terminate().catch(() => {}); }
}
