// Catatan pelanggan: nama + nomor/ID (HP, ID PLN, ID game, dll). Bukan bagian jurnal akuntansi,
// jadi boleh diubah/dihapus bebas. Tersimpan di buku sehingga ikut backup.
import { formatRupiah } from './money.js';
const cleanText = (v, max, label) => {
  const s = String(v ?? '').trim().replace(/[ \t]+/g, ' ');
  if (s.length > max) throw new Error(`${label} maksimal ${max} karakter`);
  return s;
};
export const numKey = (s) => String(s ?? '').toLowerCase().replace(/[\s\-.]/g, '');

function checkContact(book, c, selfId = null) {
  const f = { name: cleanText(c.name, 40, 'Nama'), number: cleanText(c.number, 40, 'Nomor / ID'),
    label: cleanText(c.label, 20, 'Label'), note: cleanText(c.note, 200, 'Catatan') };
  if (!f.name && !f.number) throw new Error('Isi minimal nama atau nomor / ID');
  const dup = f.number && book.contacts.find(x => x.id !== selfId && numKey(x.number) === numKey(f.number));
  if (dup) throw new Error(`Nomor sudah tersimpan atas nama ${dup.name || 'tanpa nama'}`);
  return f;
}

export function addContact(book, c) {
  book.contacts ??= [];
  const f = checkContact(book, c);
  book.contactSeq = (book.contactSeq ?? book.contacts.length) + 1;
  const ct = { id: `CT-${String(book.contactSeq).padStart(5, '0')}`, ...f, at: new Date().toISOString() };
  book.contacts.push(ct);
  return ct;
}

export function updateContact(book, id, patch) {
  const ct = (book.contacts ?? []).find(x => x.id === id);
  if (!ct) throw new Error('Catatan tidak ditemukan');
  Object.assign(ct, checkContact(book, { ...ct, ...patch }, id));
  return ct;
}

export function removeContact(book, id) {
  const i = (book.contacts ?? []).findIndex(x => x.id === id);
  if (i < 0) throw new Error('Catatan tidak ditemukan');
  book.contacts.splice(i, 1);
}

export function findContactByNumber(book, number) {
  const k = numKey(number);
  return k ? (book.contacts ?? []).find(x => numKey(x.number) === k) ?? null : null;
}

export function searchContacts(book, q) {
  const s = String(q ?? '').trim().toLowerCase(), k = numKey(q);
  const list = [...(book.contacts ?? [])].sort((a, b) => (a.name || a.number).localeCompare(b.name || b.number, 'id'));
  if (!s) return list;
  return list.filter(x => [x.name, x.label, x.note].some(v => v.toLowerCase().includes(s)) || (k && numKey(x.number).includes(k)));
}

// ---- Teks siap salin / kirim ----
const longDay = (d) => new Date(`${d}T00:00:00`).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });

export function receiptText(t) {
  const out = [t.product, `${formatRupiah(t.price)} · ${t.category}`, longDay(t.date) + (t.time ? ` ${t.time}` : '')];
  if (t.target) out.push(`No./ID: ${t.target}`);
  if (t.kind === 'income' && ['pending', 'berhasil'].includes(t.status)) out.push(`Status: ${t.paid === false ? 'Belum bayar' : 'Lunas'}`);
  else if (t.status !== 'berhasil') out.push(`Status: ${t.status}`);
  if (t.note) out.push(`Catatan: ${t.note}`);
  return out.join('\n');
}

// ---- Struk (teks monospasi lebar 32 kolom, siap salin / bagikan) ----
const stW = 32;
const stRow = (l, r) => l + ' '.repeat(Math.max(1, stW - l.length - r.length)) + r;
const stWrap = (s) => String(s).match(new RegExp(`.{1,${stW}}(\\s|$)|\\S+`, 'g'))?.map(x => x.trim()).filter(Boolean) ?? [];
export function strukText(t, shop = '') {
  const line = '-'.repeat(stW), tr = t.kind === 'transfer', rp = formatRupiah;
  const out = [(shop || 'KonterBook').toUpperCase().slice(0, stW), line, stRow('No', `TRX-${t.id.slice(3)}`), stRow('Tanggal', `${t.date}${t.time ? ' ' + t.time : ''}`),
    stRow('Jenis', { income: 'Pendapatan', expense: 'Pengeluaran', transfer: 'Transfer' }[t.kind]), line];
  if (!tr) { out.push(...stWrap(t.product)); if (t.category !== t.product) out.push(stRow('Kategori', t.category)); }
  if (t.target) out.push(stRow('No./ID', t.target));
  if (t.note) out.push(...stWrap(`Catatan: ${t.note}`));
  out.push(line);
  if (tr) out.push(stRow('Jumlah', rp(t.price)), ...(t.fee ? [stRow('Pajak', rp(t.fee))] : []), stRow('TOTAL', rp(t.price + (t.fee ?? 0))));
  else out.push(stRow('TOTAL', rp(t.price)));
  if (t.kind === 'income' && ['pending', 'berhasil'].includes(t.status)) out.push(stRow('Status', t.paid === false ? 'Belum bayar' : 'Lunas'));
  else if (t.status !== 'berhasil') out.push(stRow('Status', t.status));
  out.push(line, 'Terima kasih');
  return out.join('\n');
}

export function reminderText(rows, shop = '') {
  const total = rows.reduce((s, t) => s + t.price, 0);
  return [rows.length > 1 ? 'Halo, mengingatkan ada pembayaran yang belum diselesaikan:' : 'Halo, mengingatkan ada pembayaran yang belum diselesaikan.',
    ...rows.map(t => `- ${t.product} (${longDay(t.date)}): ${formatRupiah(t.price)}`),
    ...(rows.length > 1 ? [`Total: ${formatRupiah(total)}`] : []),
    'Mohon konfirmasinya jika sudah dibayar. Terima kasih.', ...(shop ? [`- ${shop}`] : [])].join('\n');
}

// Nomor WhatsApp (62…) jika teks tampak seperti nomor HP Indonesia; selain itu null (mis. ID PLN / ID game).
export function waNumber(s) {
  const raw = String(s ?? '').replace(/[\s\-.()]/g, '');
  if (/^\+?62\d{9,12}$/.test(raw)) return raw.replace('+', '');
  if (/^08\d{8,11}$/.test(raw)) return `62${raw.slice(1)}`;
  return null;
}
