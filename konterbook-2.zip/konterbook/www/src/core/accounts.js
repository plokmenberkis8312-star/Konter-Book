// Bagan akun awal. type: asset | liability | equity | revenue | cogs | expense
export const CHART = [
  ['1101', 'Kas Tunai', 'asset'],
  ['1102', 'Rekening Bank', 'asset'],
  ['1201', 'Deposit Server Pulsa', 'asset'],
  ['1202', 'Deposit Server PPOB', 'asset'],
  ['1203', 'Saldo E-Wallet', 'asset'],
  ['1301', 'Piutang Usaha', 'asset'],
  ['2101', 'Utang Usaha', 'liability'],
  ['3101', 'Modal Pemilik', 'equity'],
  ['4101', 'Penjualan', 'revenue'],
  ['5101', 'Harga Pokok Penjualan', 'cogs'],
  ['6101', 'Biaya Operasional', 'expense'],
];
