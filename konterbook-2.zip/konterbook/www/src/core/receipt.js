// Membaca teks hasil OCR (struk, bukti transfer, screenshot e-wallet) menjadi SARAN isian transaksi.
// Fungsi murni: tidak menulis apa pun. Pengguna selalu memeriksa dan memilih sendiri sebelum diterapkan.
const rcBulan = { jan: 1, feb: 2, mar: 3, apr: 4, mei: 5, may: 5, jun: 6, jul: 7, agu: 8, agt: 8, aug: 8, sep: 9, okt: 10, oct: 10, nov: 11, des: 12, dec: 12 };
const rcPad = (n) => String(n).padStart(2, '0');
const rcValid = (y, m, d) => { const t = new Date(y, m - 1, d); return t.getFullYear() === y && t.getMonth() === m - 1 && t.getDate() === d; };
const rcLines = (text) => String(text ?? '').split(/\r?\n/).map(s => s.trim()).filter(Boolean);

// ---- Nominal: skor per kandidat berdasarkan kata di baris itu / baris sebelumnya ----
const RC_POS = [[/total\s*(bayar|pembayaran|tagihan|transaksi|harga)/, 8], [/\btotal\b/, 6], [/jumlah|nominal/, 4], [/tagihan|harga/, 3], [/bayar|transfer|top\s?-?up|pembelian/, 2]];
const RC_NEG = [[/saldo|kembali|sisa/, -7], [/admin|biaya|fee|ppn|pajak|diskon|potongan|cashback|poin|point/, -5], [/tunai|cash/, -2]];

function rcAmounts(line) {
  const fixed = line.replace(/(rp\.?\s*|idr\s*)([0-9OoIl.,]+)/gi, (m, p, n) => p + n.replace(/[Oo]/g, '0').replace(/[Il]/g, '1'));
  const out = [], re = /(?<![\d.,])(\d{1,3}(?:[.,]\d{3})+|\d{4,})(?:[.,]\d{2})?(?![\d])/g;
  for (let m; (m = re.exec(fixed));) {
    const raw = m[1], value = Number(raw.replace(/[.,]/g, '')), rp = /(rp\.?|idr)\s*$/i.test(fixed.slice(0, m.index));
    if (!Number.isSafeInteger(value) || value < 500 || String(value).length > 12) continue;
    if (/^0/.test(raw) && raw.length >= 9) continue;                         // nomor HP / ID
    if (!rp && /^\d{4}$/.test(raw) && value >= 1990 && value <= 2100) continue; // tahun
    out.push({ value, rp });
  }
  return out;
}

function rcPrice(lines) {
  let best = null;
  lines.forEach((line, i) => {
    const own = line.toLowerCase(), ctx = `${lines[i - 1] ?? ''} ${own}`.toLowerCase();
    if (/\b(ref|trx|invoice|resi|order|no\.?\s*(hp|meter|pelanggan))\b/.test(own) && !/rp/.test(own)) return;
    for (const a of rcAmounts(line)) {
      let score = a.rp ? 2 : 0;
      for (const [re, v] of RC_POS) if (re.test(own)) { score += v; break; } else if (re.test(ctx)) { score += v * 0.6; break; }
      for (const [re, v] of RC_NEG) if (re.test(own)) { score += v; break; } else if (re.test(ctx)) { score += v * 0.5; break; }
      if (score <= 0 && !a.rp) continue;
      if (!best || score > best.score || (score === best.score && a.value > best.value)) best = { value: a.value, score, from: line };
    }
  });
  return best;
}

// ---- Tanggal & jam ----
function rcDate(text, today) {
  const t0 = new Date(`${today}T00:00:00`), limit = new Date(t0.getTime() + 864e5), yMax = t0.getFullYear();
  const cands = [];
  for (const m of text.matchAll(/(?<!\d)(\d{4})-(\d{2})-(\d{2})(?!\d)/g)) cands.push([m.index, +m[1], +m[2], +m[3], m[0]]);
  for (const m of text.matchAll(/(?<![\d/.-])(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4}|\d{2})(?![\d])/g)) cands.push([m.index, +m[3] < 100 ? 2000 + +m[3] : +m[3], +m[2], +m[1], m[0]]);
  for (const m of text.matchAll(/(?<!\d)(\d{1,2})\s+([A-Za-z]{3,9})\.?,?\s+(\d{4})(?!\d)/g)) {
    const mo = rcBulan[m[2].slice(0, 3).toLowerCase()]; if (mo) cands.push([m.index, +m[3], mo, +m[1], m[0]]);
  }
  cands.sort((a, b) => a[0] - b[0]);
  for (const [, y, mo, d, from] of cands) {
    if (y < 2000 || y > yMax || !rcValid(y, mo, d)) continue;
    if (new Date(y, mo - 1, d) > limit) continue;
    return { value: `${y}-${rcPad(mo)}-${rcPad(d)}`, from };
  }
  return null;
}

function rcTime(text) {
  const a = text.match(/(?<![\d:])([01]?\d|2[0-3]):([0-5]\d)(?::[0-5]\d)?(?![\d:])/);
  if (a) return { value: `${rcPad(+a[1])}:${a[2]}`, from: a[0] };
  const b = text.match(/(?<![\d.])([01]\d|2[0-3])\.([0-5]\d)(?:\.[0-5]\d)?\s*(?:WIB|WITA|WIT)\b/i);
  return b ? { value: `${b[1]}:${b[2]}`, from: b[0] } : null;
}

// ---- No. HP / ID pelanggan ----
const RC_ID = /(?:no\.?\s*(?:hp|handphone|telp|tujuan|meter|pelanggan|pel|ponsel)|nomor\s*(?:hp|tujuan|meter|pelanggan|telepon|ponsel)|id\s*(?:pel(?:anggan)?|game|pengguna|akun)|idpel|tujuan|user\s*id|player\s*id)\b\D{0,14}?(\d[\d -]{6,22}\d)/i;
const rcPhone = (s) => { const d = s.replace(/[^\d+]/g, '').replace(/^\+?62/, '0'); return /^08\d{8,11}$/.test(d) ? d : null; };

function rcTarget(lines) {
  for (const line of lines) {
    if (/\b(ref|trx|invoice|resi|order)\b/i.test(line)) continue;
    const m = line.match(RC_ID); if (!m) continue;
    const d = m[1].replace(/[\s-]/g, '');
    const zone = line.slice(m.index + m[0].length).match(/^\s*\((\d{3,5})\)/);   // ID game + zona, mis. 123456789 (2231)
    if (d.length >= 8 && d.length <= 24) return { value: (rcPhone(d) ?? d) + (zone ? ` (${zone[1]})` : ''), from: line };
  }
  for (const line of lines) {
    if (/\b(ref|trx|invoice|resi|order)\b/i.test(line)) continue;
    const m = line.match(/(?<![\d])(?:\+?62|0)8\d(?:[ -]?\d){7,10}(?!\d)/);
    const p = m && rcPhone(m[0]); if (p) return { value: p, from: line };
  }
  return null;
}

// ---- Nama / keterangan, kategori, referensi ----
const RC_PRODUCT = /(pulsa|paket\s*data|kuota|token(?:\s*pln)?|listrik|pln|voucher|top\s?-?up|topup|e-?wallet|dana|ovo|gopay|shopeepay|linkaja|diamond|bpjs|pdam|indihome|wifi|telkomsel|indosat|smartfren)/i;
const RC_CAT = {
  income: [[/voucher/i, 'Voucher Game'], [/dana|ovo|gopay|shopeepay|linkaja|e-?wallet/i, 'E-Wallet'], [/top\s?-?up|diamond|mobile\s*legends|free\s*fire|genshin|valorant|game/i, 'Top-up Game'],
    [/paket\s*data|kuota|data\s*\d/i, 'Paket Data'], [/token|pln|listrik/i, 'Token Listrik'], [/pulsa/i, 'Pulsa'], [/bpjs|pdam|indihome|tagihan|telkom/i, 'PPOB']],
  expense: [[/listrik|pln|token/i, 'Listrik'], [/internet|wifi|indihome/i, 'Internet'], [/sewa|kontrak/i, 'Sewa'], [/gaji/i, 'Gaji'], [/bensin|transport|ojek|parkir/i, 'Transport']],
};

const rcTitle = (s) => s === s.toUpperCase() ? s.toLowerCase().replace(/(^|\s)\S/g, c => c.toUpperCase()) : s;
function rcName(lines) {
  const person = lines.map(l => l.match(/(?:nama\s*penerima|nama\s*pelanggan|atas\s*nama|penerima|nama)\s*[:\-]\s*([A-Za-z][A-Za-z .'-]{1,30})/i)).find(Boolean);
  const clean = (l) => l.replace(/^(produk|item|layanan|keterangan|jenis)\s*[:\-]?\s*/i, '').replace(/\s+/g, ' ').trim();
  const skip = /^(total|jumlah|saldo)|struk|pembelian|transaksi|berhasil/i;
  const prod = lines.map(clean).find(l => new RegExp(`^(?:${RC_PRODUCT.source})`, 'i').test(l) && !skip.test(l))
    ?? lines.map(clean).find(l => RC_PRODUCT.test(l) && !skip.test(l));
  const p = prod ? prod.slice(0, 40) : '', n = person ? rcTitle(person[1].trim()) : '';
  if (!p && !n) return null;
  const both = `${p} ${n}`.trim();
  return { value: both.length <= 40 ? both : (p || n).slice(0, 40), from: prod ?? person[0] };
}

function rcCategory(text, list) {
  for (const [re, name] of RC_CAT[list.kind] ?? []) {
    if (!re.test(text)) continue;
    const hit = list.names.find(n => n.toLowerCase() === name.toLowerCase());
    if (hit) return { value: hit, from: name };
  }
  return null;
}

function rcRef(lines) {
  for (const line of lines) {
    const m = line.match(/(?:no\.?\s*ref(?:erensi)?|ref(?:erensi)?(?:\s*(?:no|id))?|trx\s*id|id\s*transaksi|no\.?\s*transaksi|invoice|serial\s*number|\bsn)\s*[:#.\-]?\s*([A-Za-z0-9-]{6,32})/i);
    if (m && /\d/.test(m[1])) return { value: `Ref ${m[1]}`, from: line };
  }
  return null;
}

// text: hasil OCR. opts: { today: 'YYYY-MM-DD', kind: 'income'|'expense'|'transfer', categories: [nama...] }
export function parseReceiptText(text, { today, kind = 'income', categories = [] } = {}) {
  const lines = rcLines(text), whole = lines.join('\n'), out = {};
  const put = (k, r) => { if (r) out[k] = r; };
  const pr = rcPrice(lines); if (pr) out.price = { value: pr.value, from: pr.from };
  put('date', rcDate(whole, today ?? new Date().toLocaleDateString('sv-SE')));
  put('time', rcTime(whole));
  if (kind === 'income') put('target', rcTarget(lines));
  if (kind !== 'transfer') {
    put('category', rcCategory(whole, { kind, names: categories }));
  }
  put('name', rcName(lines));
  put('note', rcRef(lines));
  return out;
}
