// Naikkan versi C setiap kali file aplikasi berubah.
const C = 'konterbook-v22';
const F = ['./', 'index.html', 'style.css', 'app.js', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png',
  'src/core/ledger.js', 'src/core/report.js', 'src/core/money.js', 'src/core/calc.js', 'src/core/accounts.js', 'src/core/notes.js', 'src/db/idb.js',
  'src/core/receipt.js', 'src/core/attach.js', 'src/core/ocr.js', 'src/db/files.js'];
self.addEventListener('install', e => e.waitUntil(caches.open(C).then(c => c.addAll(F))));
self.addEventListener('activate', e => e.waitUntil(caches.keys().then(k => Promise.all(k.filter(x => x !== C).map(x => caches.delete(x))))));
self.addEventListener('fetch', e => e.respondWith(caches.match(e.request).then(r => r || fetch(e.request))));
