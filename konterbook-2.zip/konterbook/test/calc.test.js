import test from 'node:test';
import assert from 'node:assert/strict';
import { evalExpr, pressKey, fmtExpr } from '../www/src/core/calc.js';

const type = (s, start = '') => [...s].reduce((e, k) => pressKey(e, k), start);

test('evalExpr: prioritas operator, operator menggantung, bagi nol', () => {
  assert.equal(evalExpr('2+3×4'), 14);
  assert.equal(evalExpr('15000+2500×2'), 20000);
  assert.equal(evalExpr('10÷4'), 2.5);
  assert.equal(evalExpr('100-30+5'), 75);
  assert.equal(evalExpr('5+'), 5);
  assert.equal(evalExpr(''), 0);
  assert.throws(() => evalExpr('5÷0'), /dibagi 0/);
});

test('pressKey: lanjut dari angka awal, nol di depan, operator ganda, 000', () => {
  assert.equal(type('+5'), '5');
  assert.equal(type('00'), '0');
  assert.equal(type('7', '0'), '7');
  assert.equal(type('+2×+', '15000'), '15000+2+');
  assert.equal(pressKey('5', '000'), '5000');
  assert.equal(pressKey('', '000'), '');
  assert.equal(pressKey('0', '000'), '0');
  assert.equal(pressKey('12', 'back'), '1');
  assert.equal(pressKey('12+3', 'C'), '');
  assert.equal(fmtExpr('15000+2500'), '15.000+2.500');
});
