import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createBook, openAccount, recordSale, transfer, reverseEntry,
  postEntry, profitLoss, balance, isBalanced, snapshot, restore,
} from '../www/src/core/ledger.js';
import { formatRupiah, parseRupiah } from '../www/src/core/money.js';

const D = '2026-11-19';
const fresh = () => {
  const b = createBook();
  openAccount(b, { date: D, account: '1201', amount: 100000 });
  openAccount(b, { date: D, account: '1101', amount: 50000 });
  return b;
};
const sale = { date: D, ref: 'T1', product: 'Pulsa 10rb', cost: 10000, price: 12000, fee: 500 };

test('untung bersih: 12.000 - 10.000 - 500 = 1.500', () => {
  const b = fresh();
  recordSale(b, sale);
  assert.deepEqual(profitLoss(b, D, D), { revenue: 12000, cogs: 10000, expense: 500, gross: 2000, net: 1500 });
  assert.equal(balance(b, '1201'), 89500);
  assert.equal(balance(b, '1101'), 62000);
  assert.ok(isBalanced(b));
});

test('transfer internal bukan omzet maupun untung', () => {
  const b = fresh();
  transfer(b, { date: D, from: '1101', to: '1102', amount: 30000 });
  assert.equal(profitLoss(b, D, D).revenue, 0);
  assert.equal(balance(b, '1101'), 20000);
  assert.equal(balance(b, '1102'), 30000);
});

test('transaksi gagal/refund: pembalikan menihilkan penjualan, data tidak dihapus', () => {
  const b = fresh();
  const e = recordSale(b, sale);
  reverseEntry(b, e.id, { date: D, reason: 'gagal dari server' });
  assert.equal(profitLoss(b, D, D).net, 0);
  assert.equal(balance(b, '1201'), 100000);
  assert.equal(b.entries.length, 4);
  assert.throws(() => reverseEntry(b, e.id, { date: D, reason: 'lagi' }), /sudah dibalik/);
  recordSale(b, sale); // ref boleh dipakai ulang setelah dibalik
});

test('deteksi duplikat via ref', () => {
  const b = fresh();
  recordSale(b, sale);
  assert.throws(() => recordSale(b, sale), /duplikat/);
});

test('saldo negatif ditolak tanpa izin', () => {
  const b = fresh();
  const big = { ...sale, ref: 'T2', cost: 200000, price: 250000 };
  assert.throws(() => recordSale(b, big), /tidak cukup/);
  recordSale(b, { ...big, allowNegative: true });
  assert.equal(balance(b, '1201'), 100000 - 200500);
});

test('validasi: float, tidak seimbang, jual di bawah modal', () => {
  const b = fresh();
  assert.throws(() => recordSale(b, { ...sale, price: 12000.5 }), /bilangan bulat/);
  assert.throws(() => postEntry(b, { date: D, lines: [{ account: '1101', debit: 100 }, { account: '3101', credit: 90 }] }), /tidak seimbang/);
  assert.throws(() => recordSale(b, { ...sale, ref: 'T9', price: 10000 }), /di bawah modal/);
});

test('rupiah: parse dan format', () => {
  assert.equal(parseRupiah('Rp12.000'), 12000);
  assert.equal(formatRupiah(1500), 'Rp1.500');
  assert.throws(() => parseRupiah('12.5'), /Desimal/);
});

test('backup dan restore mempertahankan saldo', () => {
  const b = fresh();
  recordSale(b, sale);
  const r = restore(snapshot(b));
  assert.equal(balance(r, '1201'), 89500);
  assert.equal(profitLoss(r, D, D).net, 1500);
});

import { addTransaction, setStatus } from '../www/src/core/ledger.js';

test('status: pending/gagal tidak masuk jurnal, berhasil masuk, refund membalik', () => {
  const b = fresh();
  const t = addTransaction(b, { date: D, product: 'Pulsa 10rb', cost: 10000, price: 12000, fee: 500 });
  assert.equal(profitLoss(b, D, D).revenue, 0);
  setStatus(b, t.id, 'berhasil', D);
  assert.equal(profitLoss(b, D, D).net, 1500);
  setStatus(b, t.id, 'refund', D);
  assert.equal(profitLoss(b, D, D).net, 0);
  assert.throws(() => setStatus(b, t.id, 'berhasil', D), /tidak bisa/);
  const g = addTransaction(b, { date: D, product: 'X', cost: 5000, price: 6000 });
  setStatus(b, g.id, 'gagal', D);
  assert.equal(profitLoss(b, D, D).revenue, 0);
});

test('transaksi berhasil dengan saldo kurang ditolak dan tidak tersimpan', () => {
  const b = fresh();
  assert.throws(() => addTransaction(b, { date: D, product: 'Besar', cost: 200000, price: 250000, status: 'berhasil' }), /tidak cukup/);
  assert.equal(b.transactions.length, 0);
});

test('pengeluaran, transfer, pendapatan tanpa modal, dan pembatalan', () => {
  const b = fresh();
  const ex = addTransaction(b, { kind: 'expense', date: D, price: 20000, category: 'Listrik', method: '1101' });
  assert.equal(ex.status, 'berhasil');
  assert.equal(balance(b, '1101'), 30000);
  addTransaction(b, { kind: 'transfer', date: D, price: 10000, source: '1101', method: '1102' });
  assert.equal(balance(b, '1102'), 10000);
  addTransaction(b, { kind: 'income', date: D, price: 5000, status: 'berhasil', method: '1101' });
  assert.deepEqual(profitLoss(b, D, D), { revenue: 5000, cogs: 0, expense: 20000, gross: 5000, net: -15000 });
  setStatus(b, ex.id, 'dibatalkan', D);
  assert.equal(profitLoss(b, D, D).expense, 0);
  assert.equal(balance(b, '1101'), 45000);
  assert.throws(() => addTransaction(b, { date: 'x', price: 1000 }), /Tanggal/);
  assert.throws(() => addTransaction(b, { kind: 'transfer', date: D, price: 1000, source: '1101', method: '1101' }), /berbeda/);
  assert.equal(b.transactions.length, 3);
});

import { addCategory, removeCategory } from '../www/src/core/ledger.js';

test('kategori kustom: tambah, duplikat, hapus, ikut backup, backup lama tetap terbaca', () => {
  const b = createBook();
  assert.equal(addCategory(b, 'income', '  Kartu   Perdana '), 'Kartu Perdana');
  assert.throws(() => addCategory(b, 'income', 'kartu perdana'), /sudah ada/);
  assert.throws(() => addCategory(b, 'income', ''), /wajib/);
  assert.throws(() => addCategory(b, 'transfer', 'X'), /tidak valid/);
  const r = restore(snapshot(b));
  assert.ok(r.categories.income.includes('Kartu Perdana'));
  removeCategory(r, 'income', 'Kartu Perdana');
  assert.ok(!r.categories.income.includes('Kartu Perdana'));
  const old = JSON.parse(snapshot(createBook())); delete old.categories;
  assert.ok(restore(JSON.stringify(old)).categories.expense.length > 0);
  const c = createBook(); c.categories.expense = ['A'];
  assert.throws(() => removeCategory(c, 'expense', 'A'), /Minimal/);
});

import { settleTransaction, addAccount, removeAccount } from '../www/src/core/ledger.js';
import { demoBook } from '../www/src/core/demo.js';

test('belum bayar jadi piutang, lunas memindahkan ke akun, refund membalik keduanya', () => {
  const b = fresh();
  const t = addTransaction(b, { date: D, product: 'Pulsa', cost: 10000, price: 12000, fee: 500, status: 'berhasil', paid: false, method: '1101' });
  assert.equal(balance(b, '1301'), 12000);
  assert.equal(balance(b, '1101'), 50000);
  assert.equal(profitLoss(b, D, D).net, 0);               // belum bayar: belum dihitung sebagai pendapatan
  settleTransaction(b, t.id, D);
  assert.equal(profitLoss(b, D, D).net, 1500);            // lunas: baru dihitung
  assert.equal(balance(b, '1301'), 0);
  assert.equal(balance(b, '1101'), 62000);
  assert.throws(() => settleTransaction(b, t.id, D), /tidak menunggu/);
  setStatus(b, t.id, 'refund', D);
  assert.equal(balance(b, '1301'), 0);
  assert.equal(balance(b, '1101'), 50000);
  assert.equal(balance(b, '1201'), 100000);
  assert.equal(profitLoss(b, D, D).net, 0);
  assert.ok(isBalanced(b));
});

test('refund gagal tidak meninggalkan jurnal setengah jadi', () => {
  const b = fresh();
  const t = addTransaction(b, { date: D, product: 'Pulsa', cost: 10000, price: 12000, status: 'berhasil', paid: false });
  settleTransaction(b, t.id, D);
  addTransaction(b, { kind: 'expense', date: D, price: 55000, method: '1101' });
  const n = b.entries.length;
  assert.throws(() => setStatus(b, t.id, 'refund', D), /tidak cukup/);
  assert.equal(b.entries.length, n);
  assert.equal(t.status, 'berhasil');
  assert.ok(isBalanced(b));
});

test('akun kustom: tambah, dipakai, tidak bisa dihapus bila punya riwayat', () => {
  const b = fresh();
  const code = addAccount(b, ' DANA  ');
  assert.equal(b.accounts[code].name, 'DANA');
  assert.throws(() => addAccount(b, 'dana'), /sudah ada/);
  assert.throws(() => addAccount(b, 'tunai'), /sudah ada/);
  openAccount(b, { date: D, account: code, amount: 20000 });
  assert.equal(balance(b, code), 20000);
  assert.throws(() => removeAccount(b, code), /riwayat/);
  assert.throws(() => removeAccount(b, '1101'), /bawaan/);
  const c = addAccount(b, 'Bank BRI');
  removeAccount(b, c);
  assert.equal(b.accounts[c], undefined);
});

test('data contoh valid, seimbang, ada piutang dan untung', () => {
  const b = demoBook();
  assert.ok(isBalanced(b));
  assert.ok(balance(b, '1301') > 0);
  assert.ok(profitLoss(b, '0000-01-01', '9999-12-31').net > 0);
  assert.ok(b.transactions.length >= 10);
});

import { editTransaction } from '../www/src/core/ledger.js';

test('edit transaksi: koreksi nominal/tanggal/status bayar/jenis, jurnal lama dibalik', () => {
  const b = fresh();
  const t = addTransaction(b, { date: D, time: '10:15', product: 'Pulsa', cost: 10000, price: 12000, fee: 500, status: 'berhasil', method: '1101' });
  assert.equal(t.time, '10:15');
  editTransaction(b, t.id, { price: 13000, date: '2026-11-18', time: '09:00' });
  assert.equal(t.date, '2026-11-18');
  assert.equal(profitLoss(b, D, D).net, 0);
  assert.equal(profitLoss(b, '2026-11-18', '2026-11-18').net, 2500);
  assert.equal(balance(b, '1101'), 63000);
  assert.equal(balance(b, '1201'), 89500);
  editTransaction(b, t.id, { paid: false });
  assert.equal(balance(b, '1301'), 13000);
  assert.equal(balance(b, '1101'), 50000);
  settleTransaction(b, t.id, D);
  assert.equal(balance(b, '1101'), 63000);
  editTransaction(b, t.id, { kind: 'expense', price: 3000, method: '1101' });
  assert.equal(profitLoss(b, '2026-11-18', '2026-11-18').revenue, 0);
  assert.equal(balance(b, '1201'), 100000);
  assert.equal(balance(b, '1101'), 47000);
  assert.ok(isBalanced(b));
});

test('edit: transaksi tertutup ditolak, edit yang gagal dibatalkan total', () => {
  const b = fresh();
  const g = addTransaction(b, { date: D, product: 'X', cost: 5000, price: 6000 });
  setStatus(b, g.id, 'gagal', D);
  assert.throws(() => editTransaction(b, g.id, { price: 7000 }), /ditutup/);
  const t = addTransaction(b, { date: D, product: 'Pulsa', cost: 10000, price: 12000, status: 'berhasil' });
  const n = b.entries.length;
  assert.throws(() => editTransaction(b, t.id, { cost: 500000, price: 600000 }), /tidak cukup/);
  assert.equal(b.entries.length, n);
  assert.equal(t.price, 12000);
  assert.equal(balance(b, '1201'), 90000);
  assert.throws(() => editTransaction(b, t.id, { time: '25:99' }), /Jam/);
});

import { deleteTransaction, setPaid, deleteAccount, restoreAccount, liveTransactions, recognizedDate, setSettings } from '../www/src/core/ledger.js';

const mk = (b, o = {}) => addTransaction(b, { date: D, product: 'Pulsa', cost: 10000, price: 12000, fee: 500, status: 'berhasil', method: '1101', ...o });

test('hapus transaksi berhasil: jurnal dibalik, laporan & saldo kembali, riwayat tetap ada', () => {
  const b = fresh();
  const t = mk(b);
  const before = b.entries.length;
  deleteTransaction(b, t.id);
  assert.equal(t.deleted, true);
  assert.equal(liveTransactions(b).length, 0);
  assert.equal(b.transactions.length, 1);                 // tidak benar-benar dibuang (id tetap unik)
  assert.equal(b.entries.length, before + 1);            // jurnal pembalik, bukan hapus jurnal
  assert.deepEqual(profitLoss(b, D, D), { revenue: 0, cogs: 0, expense: 0, gross: 0, net: 0 });
  assert.equal(balance(b, '1201'), 100000);
  assert.equal(balance(b, '1101'), 50000);
  assert.ok(isBalanced(b));
  assert.throws(() => deleteTransaction(b, t.id), /tidak ditemukan/);
  assert.throws(() => editTransaction(b, t.id, { price: 99000 }), /dihapus/);
  assert.equal(addTransaction(b, { date: D, product: 'Baru', price: 1000, status: 'berhasil' }).id, 'TX-000002');
});

test('hapus transaksi: yang sudah dilunasi, belum bayar, pending, gagal, transfer & pengeluaran', () => {
  const b = fresh();
  const paid = mk(b, { paid: false });
  settleTransaction(b, paid.id, D);
  deleteTransaction(b, paid.id);
  assert.equal(balance(b, '1101'), 50000);
  const unpaid = mk(b, { paid: false });
  assert.equal(balance(b, '1301'), 12000);
  deleteTransaction(b, unpaid.id);
  assert.equal(balance(b, '1301'), 0);
  const p = addTransaction(b, { date: D, product: 'P', cost: 5000, price: 6000 });
  deleteTransaction(b, p.id);
  const g = addTransaction(b, { date: D, product: 'G', cost: 5000, price: 6000 });
  setStatus(b, g.id, 'gagal', D);
  const n = b.entries.length;
  deleteTransaction(b, g.id);
  assert.equal(b.entries.length, n);                      // sudah dibalik sebelumnya, tidak dibalik dua kali
  const ex = addTransaction(b, { kind: 'expense', date: D, price: 20000, method: '1101' });
  const tr = addTransaction(b, { kind: 'transfer', date: D, price: 10000, source: '1101', method: '1102' });
  deleteTransaction(b, ex.id); deleteTransaction(b, tr.id);
  assert.equal(balance(b, '1101'), 50000);
  assert.equal(balance(b, '1102'), 0);
  assert.equal(liveTransactions(b).length, 0);
  assert.ok(isBalanced(b));
});

test('hapus transaksi ditolak & dibatalkan total jika membuat saldo minus', () => {
  const b = fresh();
  const t = mk(b);                                        // kas 62.000
  addTransaction(b, { kind: 'expense', date: D, price: 60000, method: '1101' });
  const n = b.entries.length;
  assert.throws(() => deleteTransaction(b, t.id), /tidak cukup/);
  assert.equal(b.entries.length, n);
  assert.ok(!t.deleted);
  assert.ok(isBalanced(b));
});

test('setPaid: sudah bayar <-> belum bayar tanpa edit manual', () => {
  const b = fresh();
  const t = mk(b);                                        // dibuat sudah bayar
  setPaid(b, t.id, false, D);
  assert.equal(t.paid, false);
  assert.equal(balance(b, '1301'), 12000);
  assert.equal(balance(b, '1101'), 50000);
  assert.equal(profitLoss(b, D, D).net, 0);               // belum bayar: tidak dihitung sebagai untung
  setPaid(b, t.id, true, D);
  assert.equal(balance(b, '1301'), 0);
  assert.equal(balance(b, '1101'), 62000);
  setPaid(b, t.id, true, D);                              // tidak berubah jika sudah sama
  setPaid(b, t.id, false, D);                             // bolak-balik setelah pelunasan
  assert.equal(balance(b, '1101'), 50000);
  assert.equal(balance(b, '1301'), 12000);
  const pend = addTransaction(b, { date: D, product: 'P', cost: 5000, price: 6000 });
  setPaid(b, pend.id, false, D);
  assert.equal(pend.paid, false);
  assert.throws(() => setPaid(b, addTransaction(b, { kind: 'expense', date: D, price: 100, method: '1101' }).id, false, D), /pendapatan/);
  assert.ok(isBalanced(b));
});

test('hapus akun: tanpa riwayat dihapus sungguhan, protected tidak bisa', () => {
  const b = fresh();
  const c = addAccount(b, 'DANA');
  assert.equal(deleteAccount(b, c), 'dihapus');
  assert.equal(b.accounts[c], undefined);
  assert.throws(() => deleteAccount(b, '1101'), /utama/);
  assert.throws(() => deleteAccount(b, '1301'), /Piutang/);
  assert.throws(() => deleteAccount(b, '9999'), /tidak ditemukan/);
});

test('hapus akun berriwayat: saldo dipindah, diarsipkan, laporan utuh, bisa diaktifkan lagi', () => {
  const b = fresh();
  const c = addAccount(b, 'DANA');
  openAccount(b, { date: D, account: c, amount: 20000 });
  mk(b, { source: c });                                   // memakai DANA sebagai sumber modal
  const net = profitLoss(b, D, D).net, bal = balance(b, c);
  assert.ok(bal > 0);
  assert.throws(() => deleteAccount(b, c), /akun tujuan/);
  assert.throws(() => deleteAccount(b, c, { moveTo: c }), /akun tujuan/);
  assert.throws(() => deleteAccount(b, c, { moveTo: '1301' }), /akun tujuan/);
  assert.equal(deleteAccount(b, c, { moveTo: '1102', date: D }), 'diarsipkan');
  assert.equal(b.accounts[c].archived, true);
  assert.equal(balance(b, c), 0);
  assert.equal(balance(b, '1102'), bal);
  assert.equal(profitLoss(b, D, D).net, net);
  assert.ok(isBalanced(b));
  assert.throws(() => deleteAccount(b, c, { moveTo: '1102' }), /sudah dihapus/);
  assert.equal(addAccount(b, 'DANA') !== c, true);        // nama akun arsip boleh dipakai ulang
  assert.throws(() => restoreAccount(b, c), /nama yang sama/);
  removeAccount(b, addAccount(b, 'XX'));
  const d = addAccount(b, 'Sementara');
  openAccount(b, { date: D, account: d, amount: 1000 });
  deleteAccount(b, d, { moveTo: '1101', date: D });
  restoreAccount(b, d);
  assert.equal(b.accounts[d].archived, undefined);
});

test('hapus akun: transaksi pending/belum bayar dipindah ke akun tujuan; transaksi lama pada akun arsip tidak bisa dibalik', () => {
  const b = fresh();
  const c = addAccount(b, 'DANA');
  const pend = addTransaction(b, { date: D, product: 'P', cost: 5000, price: 6000, method: c });
  const unp = mk(b, { paid: false, method: c });
  const old = addTransaction(b, { kind: 'expense', date: D, price: 100, method: '1101' });
  assert.throws(() => deleteAccount(b, c), /akun tujuan/);   // ada transaksi terbuka walau saldo 0
  deleteAccount(b, c, { moveTo: '1101', date: D });
  assert.equal(pend.method, '1101');
  assert.equal(unp.method, '1101');
  settleTransaction(b, unp.id, D);                           // pelunasan masuk ke akun tujuan baru
  assert.equal(balance(b, '1301'), 0);
  const d = addAccount(b, 'BRI');
  openAccount(b, { date: D, account: d, amount: 50000 });
  const t2 = addTransaction(b, { date: D, product: 'Z', cost: 1000, price: 2000, status: 'berhasil', method: d });
  deleteAccount(b, d, { moveTo: '1101', date: D });
  assert.throws(() => deleteTransaction(b, t2.id), /sudah dihapus/);
  assert.throws(() => setStatus(b, t2.id, 'refund', D), /sudah dihapus/);
  assert.throws(() => editTransaction(b, t2.id, { price: 3000 }), /sudah dihapus/);
  deleteTransaction(b, old.id);                              // transaksi yang tidak menyentuh akun arsip tetap bisa
  assert.ok(isBalanced(b));
});

test('catatan pelanggan di transaksi: No./ID dan catatan tersimpan, bisa diedit, batas panjang', () => {
  const b = fresh();
  const t = mk(b, { target: ' 0812-3456-7890 ', note: 'Langganan, bayar tiap tanggal 5' });
  assert.equal(t.target, '0812-3456-7890');
  assert.equal(t.note, 'Langganan, bayar tiap tanggal 5');
  editTransaction(b, t.id, { target: '5324 1100 998' });
  assert.equal(t.target, '5324 1100 998');
  assert.equal(t.note, 'Langganan, bayar tiap tanggal 5');
  assert.throws(() => mk(b, { target: 'x'.repeat(41) }), /maksimal 40/);
  assert.throws(() => mk(b, { note: 'x'.repeat(201) }), /maksimal 200/);
  const r = restore(snapshot(b));
  assert.equal(r.transactions[0].target, '5324 1100 998');
  assert.deepEqual(r.contacts, []);                          // backup lama tanpa contacts tetap terbaca
});

const D2 = '2026-11-21', D3 = '2026-11-25';
const unpaidSale = (b, o = {}) => addTransaction(b, { date: D, product: 'Pulsa', cost: 10000, price: 12000, fee: 500, status: 'berhasil', paid: false, method: '1101', ...o });

test('pendapatan dihitung saat lunas: belum bayar tidak masuk, masuk pada tanggal pelunasan', () => {
  const b = fresh();
  const t = unpaidSale(b);
  assert.deepEqual(profitLoss(b, D, D3), { revenue: 0, cogs: 0, expense: 0, gross: 0, net: 0 });
  assert.equal(recognizedDate(b, t), null);
  settleTransaction(b, t.id, D3);
  assert.equal(recognizedDate(b, t), D3);
  assert.deepEqual(profitLoss(b, D, D), { revenue: 0, cogs: 0, expense: 0, gross: 0, net: 0 });     // hari transaksi tetap kosong
  assert.deepEqual(profitLoss(b, D3, D3), { revenue: 12000, cogs: 10000, expense: 500, gross: 2000, net: 1500 });
  assert.equal(profitLoss(b, D, D3).net, 1500);
  assert.ok(isBalanced(b));
});

test('dasar "transaksi": belum bayar tetap dihitung pada tanggal transaksi (perilaku lama)', () => {
  const b = fresh();
  setSettings(b, { basis: 'transaksi' });
  const t = unpaidSale(b);
  assert.equal(profitLoss(b, D, D).net, 1500);
  assert.equal(recognizedDate(b, t), D);
  settleTransaction(b, t.id, D3);
  assert.equal(profitLoss(b, D, D).net, 1500);
  assert.equal(profitLoss(b, D3, D3).net, 0);
  setSettings(b, { basis: 'lunas' });                       // laporan bisa dibalik kapan saja, jurnal tak berubah
  assert.equal(profitLoss(b, D3, D3).net, 1500);
});

test('lunas lalu hapus / balik ke belum bayar / refund: laporan tetap rapi, tidak timpang antar periode', () => {
  const b = fresh();
  const t = unpaidSale(b);
  settleTransaction(b, t.id, D3);
  setPaid(b, t.id, false, D3);                              // lunas -> belum bayar
  assert.equal(profitLoss(b, D, '2026-12-31').net, 0);
  setPaid(b, t.id, true, D3);
  assert.equal(profitLoss(b, D3, D3).net, 1500);
  deleteTransaction(b, t.id);                               // jurnal pembalik tanggalnya D, tapi laporan ikut tanggal pelunasan
  assert.equal(profitLoss(b, D, '2026-12-31').net, 0);
  assert.equal(profitLoss(b, D3, D3).net, 0);
  assert.equal(profitLoss(b, D, D).net, 0);
  const u = unpaidSale(b);                                  // dihapus saat masih belum bayar
  deleteTransaction(b, u.id);
  assert.equal(profitLoss(b, D, '2026-12-31').net, 0);
  const r = unpaidSale(b);                                  // refund setelah dilunasi: untung muncul saat lunas, hilang saat refund
  settleTransaction(b, r.id, D2);
  setStatus(b, r.id, 'refund', D3);
  assert.equal(profitLoss(b, D2, D2).net, 1500);
  assert.equal(profitLoss(b, D3, D3).net, -1500);
  assert.equal(profitLoss(b, D, '2026-12-31').net, 0);
  const e = unpaidSale(b);                                  // edit transaksi yang sudah lunas
  settleTransaction(b, e.id, D2);
  editTransaction(b, e.id, { price: 13000 });
  assert.equal(profitLoss(b, D, '2026-12-31').net, 2500);   // 13.000 - 10.000 - 500, tidak dihitung dobel
  assert.ok(isBalanced(b));
});

test('total semua periode sama untuk kedua dasar setelah semua piutang lunas', () => {
  const mkb = (basis) => {
    const b = fresh(); setSettings(b, { basis });
    const a = unpaidSale(b), c = unpaidSale(b, { price: 15000 }); mk(b);
    settleTransaction(b, a.id, D2); settleTransaction(b, c.id, D3);
    return profitLoss(b, '2000-01-01', '2100-01-01');
  };
  assert.deepEqual(mkb('lunas'), mkb('transaksi'));
});

test('pengaturan: validasi, backup lama tanpa settings terbaca dengan dasar lunas', () => {
  const b = fresh();
  assert.equal(b.settings.basis, 'lunas');
  assert.throws(() => setSettings(b, { basis: 'x' }), /tidak dikenal/);
  assert.throws(() => setSettings(b, { shop: 'x'.repeat(31) }), /maksimal 30/);
  setSettings(b, { shop: '  Konter   Maju  ' });
  assert.equal(b.settings.shop, 'Konter Maju');
  const old = JSON.parse(snapshot(b)); delete old.settings;
  const r = restore(JSON.stringify(old));
  assert.deepEqual(r.settings, { basis: 'lunas', shop: '', goal: 0, goalKind: 'net', startPeriod: 'day', startCustom: null });
  assert.equal(restore(snapshot(b)).settings.shop, 'Konter Maju');
});
