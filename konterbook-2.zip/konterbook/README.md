# KonterBook (nama sementara)

Aplikasi akuntansi konter digital, offline-first. JavaScript murni (tanpa build), jalan di browser, HP, dan bisa dibungkus jadi APK.

## Struktur
- `www/` : aplikasi (index.html, app.js, style.css, manifest, sw.js)
  - `www/src/core/` : money.js (rupiah integer), accounts.js (bagan akun), ledger.js (double-entry, transaksi bertatus, hapus, arsip akun), notes.js (catatan pelanggan), report.js (rincian kategori dan kartu dashboard)
  - `www/src/db/idb.js` : penyimpanan IndexedDB di perangkat
- `test/` : tes otomatis. `capacitor.config.json` : pengaturan APK.

## Aturan data
Jurnal wajib seimbang; nominal integer; **jurnal tidak pernah dihapus atau diubah**. Koreksi, refund, dan hapus dilakukan dengan jurnal pembalik, jadi saldo dan laporan selalu bisa ditelusuri. Saldo aset tidak boleh negatif; hanya status Berhasil masuk jurnal (Pending/Gagal/Batal tidak). Semua angka dashboard dihitung dari jurnal.

- **Hapus transaksi**: jurnalnya dibalik pada tanggal aslinya (laporan kembali seperti transaksi tak pernah ada) dan transaksi disembunyikan. Ditolak jika membuat saldo minus.
- **Sudah bayar / belum bayar**: bisa diubah langsung dari daftar (ketuk label Lunas / Belum bayar) atau dari detail, tanpa membuka menu Edit.
- **Hapus akun**: akun tanpa riwayat dihapus sungguhan. Akun berriwayat diarsipkan (saldo dipindah ke akun lain lewat jurnal, riwayat tetap utuh) dan bisa diaktifkan lagi di Kas. Kas Tunai dan Piutang tidak bisa dihapus.
- **Catatan pelanggan**: tab Catatan menyimpan nama, nomor HP / ID pelanggan (PLN, game, dll), label, dan catatan. Setiap transaksi juga punya kolom No. / ID dan catatan, dan semuanya bisa dicari di tab Transaksi.
- **Pendapatan dihitung saat lunas** (bawaan): penjualan yang belum dibayar tidak masuk omzet/untung; baru dihitung pada hari pembeli melunasi. Bisa diganti ke "Transaksi" di Pengaturan. Jurnal tidak berubah, hanya tanggal pengakuan di laporan.
- **Piutang**: menu di Kas (atau ketuk kartu Total piutang di Dashboard). Utang dikelompokkan per pembeli (nomor / ID), ada umur utang, salin tagihan, tagih via WhatsApp, lunasi semua, dan ketuk transaksi untuk menuju barisnya di tab Transaksi.
- **Salin**: detail transaksi, nomor pelanggan, dan pesan tagihan bisa disalin sekali ketuk.
- **Pengaturan** (ikon gerigi di pojok kanan atas): tema Otomatis/Terang/Gelap, dasar pendapatan, nama usaha, ekspor/impor cadangan (JSON), hapus semua data.

## Baru di v0.22 (pilih, urutan, salin)
- **Mode pilih lebih jelas**: tiap baris punya kotak centang bulat yang muncul dari kiri; baris terpilih berwarna dan bercentang. Bar bawah dirombak: tombol batal (✕), jumlah dipilih + total nominal (dan "dari N"), tombol **Semua / Kosongkan**, dan tombol **Hapus** merah berlencana jumlah. Tombol tambah (+) disembunyikan selama memilih.
- **Konfirmasi hapus** menampilkan daftar ringkas transaksi yang akan dihapus (maks. 4 + "N lainnya") dan totalnya. Setelah dikonfirmasi baris menciut halus; bila gagal (mis. saldo akan minus) baris kembali dan tidak ada yang terhapus.
- **Urutan lebih mulus**: pegangan ⠿ di kanan tiap baris (saat mode pilih) bisa diseret **langsung** tanpa menahan; tahan lalu geser tetap bisa. Baris yang diseret terangkat (membesar sedikit), tidak bisa keluar dari kelompok harinya, meluncur ke posisi barunya saat dilepas, tanpa kedip putih (daftar tidak digambar ulang dengan animasi masuk). Bar bawah memudar selama menyeret supaya tidak menutupi daftar. Bila hari itu hanya punya 1 transaksi muncul pemberitahuan.
- **Salin transaksi**: tombol Salin di detail kini membuka dropdown di tempat (gaya pilihan periode Hari/Minggu/...) dengan 2 pilihan: **Tanggal & jam sama** (dengan transaksi yang disalin) atau **Tanggal & jam hari ini**. Tiap pilihan menampilkan tanggal + jam yang akan dipakai (jam hari ini selalu segar saat menu dibuka). Selebihnya sama seperti v0.11 (form terisi, baru tersimpan saat Simpan).
- **Penanda menu bawah tanpa jeda**: saat geser antar menu, penanda (Dashboard/Transaksi/Catatan/Kas) langsung pindah begitu geseran cukup jauh dan seketika saat jari dilepas, tidak menunggu animasi selesai. Berlaku juga saat menekan tombol menu.
- **Kartu dashboard bisa ditutup / dibuka**: grafik Pemasukan vs pengeluaran, Kategori terlaris (pie), dan Jam ramai punya tombol **Tutup / Buka** di pojok kanan atas. Saat ditutup kartu menciut halus jadi satu baris ringkasan (mis. "Pemasukan Rp… · Modal + biaya Rp…"). Pilihan tersimpan di perangkat dan diingat saat aplikasi dibuka lagi; tidak masuk cadangan dan tidak mengubah data.
- **Jam ramai tampil baru**: ketuk batang jam mana pun untuk melihat rinciannya (rentang jam, jumlah penjualan, persen, omzet jam itu); batang makin pekat makin ramai, jam puncak ditandai, ada garis bantu. Di bawahnya ada **Bagian hari** (Pagi / Siang / Sore / Malam dengan persen) dan **3 jam teratas** berperingkat.
- Tidak ada perubahan pada jurnal, ID, database, atau format cadangan. Cache Service Worker jadi `konterbook-v22`.

## Baru di v0.21 (tahan transaksi)
- **Tahan** transaksi = mode pilih (tanpa menu dan tanpa getaran). **Ketuk** transaksi lain untuk menambah / mengurangi pilihan; tombol **Semua** memilih semua yang sedang tampil.
- **Tahan lalu geser** = pindahkan urutan langsung dengan jari, di dalam hari yang sama (halaman menggulir sendiri di dekat tepi layar). Tidak ada tombol urutan lagi. ID dan jurnal tidak berubah.
- **Hapus banyak** lewat bar bawah, selalu dengan konfirmasi "Hapus N transaksi?". Semua-atau-tidak-sama-sekali: bila salah satu gagal (mis. saldo akan minus), tidak ada yang terhapus. Hanya transaksi yang terlihat yang bisa ikut terhapus. Lampiran gambarnya ikut dihapus.
- Desktop: klik kanan = pilih; tahan mouse lalu seret = urutan. `Esc` membatalkan.

## Baru di v0.11
- **Salin transaksi**: tombol Salin di detail membuka form terisi dari transaksi lama (tanggal dan jam = sekarang), langsung siap diubah. Baru tersimpan saat Simpan, jadi batal tidak membuat data ganda. Akun yang sudah dihapus diganti ke akun bawaan. Salin teks tetap ada sebagai tombol Salin teks.
- **Warna jenis**: Pendapatan biru, Pengeluaran merah, Transfer ungu (daftar, detail, form).
- **Teks tampilan tidak bisa diseleksi** (tombol, judul, angka), jadi menu Select tidak muncul tak sengaja. Kolom isian tetap bisa diseleksi.
- **Kategori**: dari Dashboard (Lihat semua kategori), Kas, atau detail transaksi. Daftar kategori per periode lengkap dengan jumlah, nominal, untung; ketuk kategori untuk penghitungan (rata-rata, terbesar/terkecil, modal, untung, margin, rincian per nominal, piutang, status lain) dan daftar transaksinya.
- **Kartu dashboard bisa diketuk**: Omzet, Untung kotor, Modal, Pengeluaran, Transaksi, dan Untung bersih membuka halaman rincian (per kategori, per akun, perbandingan periode, daftar transaksi). Angka utama sama dengan dashboard; refund/pembatalan di tanggal berbeda tampil sebagai baris selisih.

## Baru di v0.12 (tampilan)
- Desain baru yang lebih simpel dan profesional: kartu rata dengan garis tipis, bayangan dihapus, sudut lebih rapi, mode terang dan gelap.
- Dashboard: kartu saldo dan untung bersih berwarna solid, kartu statistik lebih ringkas, menu cepat berbentuk baris.
- Daftar transaksi: ikon jenis (masuk, keluar, transfer), judul, kategori, jam, dan akun tersusun rapi; jumlah dan status bayar di kanan.
- Detail transaksi: Edit jadi tombol utama, tombol lain tersusun dua kolom, ada pegangan tarik di atas.
- Navigasi bawah penuh dengan penanda garis di tab aktif; pilihan periode dan tab berupa kapsul abu dengan pilihan putih.
- Tidak ada fitur yang dihapus atau diubah; hanya tampilan.

## Baru di v0.13 (redesign total tampilan)
- **Design system baru** di `www/style.css`: token CSS (warna, tipografi, radius, gerak) untuk mode terang dan gelap, lalu komponen. Merek merah profesional, pendapatan biru, pengeluaran merah, transfer ungu, untung hijau. Jenis akun di Kas punya warna ikon sendiri (tunai, bank, deposit, e-wallet).
- **Dashboard**: hero Total saldo, selektor periode, kartu Untung bersih, enam kartu statistik, grafik, kategori terlaris, menu cepat (Transaksi baru, Catatan, Piutang, Kategori), dan **Aktivitas terbaru**.
- **Transaksi**: filter jenis, status (termasuk Sudah/Belum bayar), dan kategori, dengan tombol Reset. Filter hanya menyaring tampilan; angka ringkasan tetap dari jurnal.
- **Catatan**: jumlah pelanggan, kartu rapi (grid di layar lebar).
- **Kas**: urutan baru (Akun, Piutang, Perpindahan saldo, Keuntungan, Kelola) dan riwayat perpindahan saldo.
- **Responsif**: ponsel kecil/besar, tablet (sheet jadi dialog), desktop (navigasi bawah jadi bilah samping). Safe area Android dan keyboard virtual (`interactive-widget=resizes-content`).
- **Komponen**: tombol, input, dropdown, sheet, dialog konfirmasi, badge, toast, kondisi kosong, dan skeleton loading seragam. Area sentuh minimal 40-44px. Animasi halus, mati otomatis bila `prefers-reduced-motion`.
- Logika bisnis, database, jurnal, ekspor/impor, dan Service Worker (selain versi cache `konterbook-v12`) tidak diubah. File `src/` identik dengan v0.12.

## Baru di v0.18
- **Geser antar menu**: geser layar ke kiri / kanan untuk pindah Dashboard, Transaksi, Catatan, Kas. Halaman mengikuti jari dan menu di sebelahnya ikut terlihat, jadi geseran bisa **ditahan** di tengah. Lepas: pindah bila cukup jauh atau cepat, kalau tidak kembali (animasi halus). Di ujung daftar terasa menahan. Tombol navigasi bawah memakai animasi geser yang sama. Tidak aktif saat ada menu / form terbuka, di grafik yang bisa digeser, atau di kolom isian; gulir vertikal tidak terganggu. Mati otomatis bila `prefers-reduced-motion`.
- **Pie cerah**: palet merah, jingga, kuning, hijau muda, hijau, cyan, biru; pie lebih besar, label luar tidak terpotong, irisan muncul beranimasi dan "melompat" saat disentuh. Lencana persen berwarna cerah dengan teks yang tetap terbaca.
- **Grafik pemasukan vs pengeluaran**: garis halus (tidak turun di bawah nol), area bergradasi, label nilai dengan angka koma Indonesia, label tidak lagi menimpa sumbu tanggal atau saling bertabrakan, batang berlabel tegak (tidak terpotong), judul sumbu (Rupiah / Tanggal atau Bulan), dan ringkasan Tertinggi, Rata-rata, Selisih.
- **Pencarian transaksi**: "trx-2", "trx 0002", atau "#2" langsung menemukan TRX-000002; juga mencari jenis, status, jam, akun, dan "belum bayar".
- **Transfer**: form menampilkan "Dipotong dari akun asal" (nominal + pajak); detail menampilkan Pajak dan Total keluar. Warna label kolom aktif mengikuti jenis.
- Perbaikan: geser di ujung daftar tidak lagi membuat layar macet.

## Baru di v0.17
- **Grafik pemasukan vs pengeluaran** bergaya grafik garis berlabel (atau Batang, pilih di pojok kartu): sumbu angka di kiri, setiap titik/batang memuat angkanya, dan grafik bisa digeser ke samping untuk melihat semua hari/bulan. Ketuk titik untuk rincian.
- **Pie kategori** dengan label di luar (nama dan persen), tab Pendapatan / Pengeluaran lengkap dengan totalnya, dan daftar kategori berlencana persen. Ketuk irisan, label, atau baris kategori untuk melihat **semua riwayat transaksi** kategori itu (semua status, urut terbaru).
- **Perbaikan bug**: Modal, Biaya, kategori, dan akun yang sudah diisi tidak hilang lagi saat pindah jenis transaksi di form (mis. Pendapatan, Pengeluaran, lalu kembali ke Pendapatan).
- **Struk berupa gambar** (PNG): pratinjau, Bagikan gambar, Simpan, dan Salin teks tetap tersedia.
- **Detail transaksi**: tombol Tutup dihapus (tutup dengan ketuk area gelap atau tarik), tata letak dipadatkan jadi kisi dua kolom, dan tombol aksi selalu terlihat di bawah.

## Baru di v0.16
- Status bayar jadi satu tombol kecil di sebelah Simpan (ketuk untuk bolak-balik Sudah / Belum bayar). Warna jenis kembali: pendapatan biru, pengeluaran merah, transfer ungu.
- Lampiran dan Baca dari gambar jadi dua ikon kecil di baris Catatan; Pilih dari Catatan pindah ke baris Pelanggan.
- **Pajak transfer**: dicatat sebagai biaya (akun 6101) di luar nominal yang sampai ke tujuan; ikut laporan (Biaya > Pajak transfer).
- **ID transaksi** (TRX-000001) tampil di daftar (#1), detail, dan struk, dan bisa dicari. **Struk** menggantikan Salin teks (salin / bagikan).
- Grafik batang punya label nilai di atas batang (otomatis dikurangi bila batangnya banyak).

## Baru di v0.15 (form transaksi)
- Form Edit/Salin/Baru Transaksi didesain ulang "Clean Minimalist Red": tab garis merah, tanggal + jam berdampingan, Total besar dengan Modal dan Biaya sebagai baris info, grup dipisah garis (bukan kartu per kolom), status bayar berupa dua pilihan radio. Logika dan data tidak berubah.

## Baru di v0.14
- **Lampiran gambar**: form transaksi (kecuali Tambah saldo) dan detail transaksi punya bagian Lampiran (maks. 6 gambar: struk, bukti transfer, screenshot). Gambar diperkecil (maks. 1600 px) dan disimpan di database terpisah `konterbook-files`, jadi tidak pernah menyentuh jurnal. Ketuk thumbnail untuk penampil (zoom +/- atau ketuk dua kali, geser, navigasi). Daftar transaksi menampilkan ikon klip.
- **Baca dari gambar (OCR)**: tombol "Baca dari gambar" membaca teks lalu menyarankan nominal, tanggal, jam, No./ID, pelanggan, kategori, dan nomor referensi. Tidak ada yang terisi otomatis: Anda mencentang yang mau diterapkan. Teks bisa diedit/ditempel manual (berguna tanpa internet), dan teks gambar ikut dicari di tab Transaksi. Mesin baca (tesseract.js 5.1.1) diunduh sekali dari CDN; gambar tidak dikirim ke mana pun.
- **Menu pilihan slide-up**: filter Status dan Kategori memakai tombol yang membuka menu dari bawah (bukan dropdown bawaan). Semua menu bawah (pilihan, detail transaksi, hasil bacaan) bisa ditutup dengan menarik pegangan ke bawah.
- **Cadangan**: file JSON kini membawa gambarnya. Hapus transaksi / hapus semua data ikut menghapus gambarnya; impor menolak data selain gambar.
- Tombol Simpan tidak bisa terpencet dua kali (mencegah transaksi ganda).
- Tes: `npm test` (57 tes, termasuk parser struk dengan keluaran OCR nyata).

`npm run serve`, buka alamat yang tampil. Dari HP, buka alamat IP laptop (satu Wi-Fi). Jangan buka index.html langsung (modul JS butuh server).

## Jadi APK (Capacitor)
Prasyarat: Node 20+, JDK 21, Android Studio.
1. `npm install`
2. `npm run apk:init` (sekali saja)
3. `npm run apk:sync` (setiap `www/` berubah)
4. `npm run apk:open`, lalu di Android Studio: Build > Build APK(s)

Data tersimpan di perangkat (IndexedDB). Ekspor/impor cadangan ada di menu Kas.

## Tes
`npm test` (Node 18+, tanpa install).

## File tunggal untuk dilihat langsung
`npm run build:single` menghasilkan `dist/konterbook.html` (satu file, tanpa server). Buka dengan klik; tombol "Lihat data contoh" di Dashboard mengisi data contoh yang tidak disimpan.

## Baru di v0.19
- **Geser lebih mulus**: halaman aktif dan tetangganya jadi panel seukuran layar saat digeser (bukan lapisan setinggi seluruh isi), jadi tidak seret dan menu bawah tidak hilang. Isi halaman tetangga dipakai ulang di akhir geseran tanpa render ulang.
- **Pemilih periode & filter berupa dropdown di tempat**: Hari/Minggu/Bulan/Tahun/Semua jadi satu tombol; filter Status dan Kategori di Transaksi juga dropdown yang terbuka tepat di tombolnya (otomatis ke atas bila tidak muat). Pilihan di menu edit tetap panel dari bawah, kini lebih rapi dengan mode Kelola dan konfirmasi sebelum menghapus.
- **Pencarian transaksi** jadi tombol kecil yang membuka kolom cari di tempat.
- **Grafik**: ringkasan + perbandingan periode, garis rata-rata, penanda tertinggi, kartu rincian titik terpilih. **Pie**: ringkasan, bar porsi, label Terlaris, untung per kategori, lubang tengah kecil.
- **Target bulanan** (Pengaturan → Target bulanan): kartu di Dashboard dengan capaian, penanda posisi ideal hari ini, kebutuhan per hari, dan proyeksi akhir bulan; basis Untung bersih atau Omzet. Hanya tampilan, tidak mengubah jurnal.
- **Jam ramai**: grafik penjualan per jam untuk periode terpilih, jam puncak, dan tiga jam teratas.
- **Rekap bagikan**: ikon bagikan di Dashboard menyusun rekap periode terpilih (omzet, modal, pengeluaran, untung, kategori terlaris, piutang) untuk dibagikan, disalin, atau dikirim lewat WhatsApp.
- Tes baru untuk target, jam ramai, rekap, dan validasi pengaturan. `settings` kini punya `goal` dan `goalKind` (backup lama tetap terbaca).

## Baru di v0.20
- **Tekan tahan tanpa getaran**: menu konteks bawaan browser/Android (sumber getar dan menu salin) dimatikan; yang muncul hanya menu aplikasi. Jika HP masih bergetar karena pengaturan sistem Android ("getaran sentuh"), itu tidak bisa dimatikan dari aplikasi web; untuk APK bisa dimatikan di kode native dengan `setHapticFeedbackEnabled(false)`.
- **Tekan tahan pada transaksi** (di daftar mana pun): menu **Lihat detail**, **Atur urutan**, **Hapus** (dengan konfirmasi). Di desktop, klik kanan membuka menu yang sama.
- **Atur urutan**: bilah di bawah layar dengan tombol ke paling atas, naik, turun, ke paling bawah. Urutan berlaku dalam satu hari dan ikut cadangan. **ID, tanggal, dan jurnal tidak berubah**; hanya field tampilan `ord`. Transaksi baru tampil di atas urutan manual. Bila daftar sedang difilter, satu langkah melewati transaksi yang tersembunyi. Mengedit tanggal transaksi menghapus urutan manualnya.
- **Periode tanggal**: di menu periode ada "Pilih tanggal…" dengan kalender kecil di dalam menu (**Satu tanggal** atau **Rentang**, pintasan Kemarin / 30 hari / Bulan lalu). Dipakai di Dashboard (grafik per hari, atau per bulan bila lebih dari 62 hari), pie, jam ramai, rekap, perbandingan dengan periode sebelumnya, dan halaman rincian.
- **Periode saat membuka aplikasi** (Pengaturan): Hari ini, 7 hari terakhir, Bulan ini, Tahun ini, Semua waktu, **Terakhir dipakai**, atau **Tanggal tertentu** (satu tanggal atau rentang tetap). Bawaan tetap Hari ini; cadangan lama terbaca dengan bawaan itu.
- Tes baru untuk urutan (naik/turun/atas/bawah, ID dan jurnal tetap, urutan ikut cadangan, hari lain tidak terpengaruh) dan validasi periode awal.
